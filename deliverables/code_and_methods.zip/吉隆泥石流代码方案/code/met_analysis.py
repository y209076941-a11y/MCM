"""Auditable hourly meteorology / long-term temperature analysis.

All event links are descriptive single-event associations. Forecast intervals refer
to six-hour-ahead station temperature, not debris-flow initiation time.
Run: OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python code/met_analysis.py
"""
from pathlib import Path
import json, warnings
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
SEED=20260826
EVENT=pd.Timestamp('2026-08-26 10:30')
STOP=pd.Timestamp('2026-08-26 10:00')
warnings.filterwarnings('ignore',category=RuntimeWarning)

def plain(o):
    if isinstance(o,(np.integer,)):return int(o)
    if isinstance(o,(np.floating,)):return None if not np.isfinite(o) else float(o)
    if isinstance(o,(pd.Timestamp,)):return o.isoformat()
    if isinstance(o,np.ndarray):return o.tolist()
    raise TypeError(type(o))

def load_hourly():
    blocks={}; audit=[]; missing=[]
    for kind in ['MET','RADM','SOIL','FLUX']:
        parts=[]
        for p in sorted((ROOT/'data/dataset_1').glob(kind+'*.csv')):
            d=pd.read_csv(p,low_memory=False)
            d.index=pd.to_datetime(d.pop('Timestamp'),format='mixed')
            d=d.apply(pd.to_numeric,errors='coerce')
            parts.append(d)
        raw=pd.concat(parts).sort_index()
        assert not raw.index.duplicated().any()
        d=raw.copy()
        for c in d:
            if c.startswith('QC_'):continue
            s=d[c].mask(d[c].abs()>=9990)
            # Every quality flag is interpreted conservatively: only code 0.
            # This is an operational filter; original flag semantics are absent.
            if kind!='FLUX':
                stem=c.split('(')[0]
                match=next((q for q in d if q.lower()==('QC_'+stem).lower()),None)
                if match is not None:s=s.where(d[match].eq(0))
            if c.startswith('WS_'):s=s.where(s.between(0,60))
            elif c.startswith('WD_'):s=s.where(s.between(0,360))
            elif c.startswith('Ta_') or c.startswith('soilT_'):s=s.where(s.between(-60,50))
            elif c.startswith('RH_'):s=s.where(s.between(0,100))
            elif c.startswith('VWC_'):s=s.where(s.between(0,1))
            elif c=='Pressure(hPa)':s=s.where(s.between(400,1100))
            elif c=='Precip(mm)':s=s.where(s.between(0,150))
            elif c in ['Rsd(W/m2)','Rsu(W/m2)']:s=s.where(s.between(-20,1600)).clip(lower=0)
            elif c in ['Rld(W/m2)','Rlu(W/m2)']:s=s.where(s.between(0,800))
            elif c in ['H(W/m2)','LE(W/m2)']:s=s.where(s.between(-1000,1500))
            elif c=='USTAR(m/s)':s=s.where(s.between(0,5))
            elif c=='TKE(m2/s2)':s=s.where(s.between(0,40))
            d[c]=s
            audit.append(dict(kind=kind,variable=c,total=len(s),valid=int(s.notna().sum()),missing_pct=100*s.isna().mean(),first_valid=str(s.first_valid_index()),last_valid=str(s.last_valid_index())))
            for (year,month), part in s.groupby([s.index.year,s.index.month]):
                missing.append(dict(kind=kind,variable=c,year=year,month=month,missing_pct=100*part.isna().mean(),valid=int(part.notna().sum())))
        blocks[kind]=d.drop(columns=[c for c in d if c.startswith('QC_')])
    pd.DataFrame(audit).to_csv(OUT/'met_variable_audit.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(missing).to_csv(OUT/'met_monthly_missing.csv',index=False,encoding='utf-8-sig')
    return pd.concat(blocks.values(),axis=1),pd.DataFrame(audit)

def engineer(d):
    f=pd.DataFrame(index=d.index)
    f['T2']=d['Ta_2m(degree C)']; f['RH2']=d['RH_2m(%)']
    for h in [1,3,6,24,72]:f['P'+str(h)]=d['Precip(mm)'].rolling(h,min_periods=h).sum()
    for h in [24,72]:f['PDD'+str(h)]=f.T2.clip(lower=0).rolling(h,min_periods=h).sum()/24
    # Antecedent precipitation index, exact finite trailing 168 h, e-folding 72 h.
    w=np.exp(-np.arange(168)/72)
    f['API']=pd.Series(np.convolve(d['Precip(mm)'].fillna(0).values,w,mode='full')[:len(d)],index=d.index)
    f['API']=f.API.where(d['Precip(mm)'].rolling(168,min_periods=168).count().eq(168))
    f['VWC10']=d['VWC_0.1m(m3/m3)'];f['VWC40']=d['VWC_0.4m(m3/m3)']
    f['ST10']=d['soilT_0.1m(degree C)']
    f['Rn']=d['Rsd(W/m2)']-d['Rsu(W/m2)']+d['Rld(W/m2)']-d['Rlu(W/m2)']
    f['H']=d['H(W/m2)'];f['LE']=d['LE(W/m2)'];f['USTAR']=d['USTAR(m/s)'];f['TKE']=d['TKE(m2/s2)']
    f['WS20']=d['WS_20m(m/s)']
    t2=f.T2+273.15;p2=d['Pressure(hPa)']
    p1=p2*np.exp(-9.80665*(1-2)/(287.05*t2));p20=p2*np.exp(-9.80665*(20-2)/(287.05*t2))
    th1=(d['Ta_1m(degree C)']+273.15)*(1000/p1)**.2854
    th20=(d['Ta_20m(degree C)']+273.15)*(1000/p20)**.2854
    def uv(h):
        a=np.deg2rad(d[f'WD_{h}m(degree)']);v=d[f'WS_{h}m(m/s)']
        return -v*np.sin(a),-v*np.cos(a)
    u1,v1=uv(1);u20,v20=uv(20)
    shear=(u20-u1)**2+(v20-v1)**2
    f['RiB']=(9.80665/((th1+th20)/2)*(th20-th1)*19/shear).where(shear>=.01)
    f['dTdz']=(d['Ta_20m(degree C)']-d['Ta_1m(degree C)'])/19
    f['EBR']=(f.H+f.LE)/(f.Rn-d['G_0.1m(W/m2)'])
    f['EBR']=f.EBR.where((f.Rn-d['G_0.1m(W/m2)']).abs()>50)
    return f

NAMES={'T2':'2米气温','RH2':'2米相对湿度','P1':'1小时降雨','P3':'3小时累积降雨','P6':'6小时累积降雨','P24':'24小时累积降雨','P72':'72小时累积降雨','PDD24':'24小时正积温','PDD72':'72小时正积温','API':'前期降雨指数','VWC10':'10厘米土壤含水率','VWC40':'40厘米土壤含水率','ST10':'10厘米土壤温度','Rn':'净辐射','H':'感热通量','LE':'潜热通量','USTAR':'摩阻速度','TKE':'湍动能','WS20':'20米风速','RiB':'体积理查森数','dTdz':'1至20米温度梯度'}
UNITS={'T2':'℃','RH2':'%','P1':'mm','P3':'mm','P6':'mm','P24':'mm','P72':'mm','PDD24':'℃·d','PDD72':'℃·d','API':'mm','VWC10':'m³/m³','VWC40':'m³/m³','ST10':'℃','Rn':'W/m²','H':'W/m²','LE':'W/m²','USTAR':'m/s','TKE':'m²/s²','WS20':'m/s','RiB':'1','dTdz':'℃/m'}

def event_comparison(f):
    # A common 24-hour mean ending at the last fully observed pre-event hour.
    win=f[list(NAMES)].rolling(24,min_periods=20).mean()
    event=win.loc[STOP]
    controls=[]
    for year in range(2021,2026):
        center=pd.Timestamp(year=year,month=8,day=26,hour=10)
        for offset in range(-15,16):
            t=center+pd.Timedelta(days=offset)
            row=win.loc[t].to_dict();row['Timestamp']=t;row['year']=year
            controls.append(row)
    c=pd.DataFrame(controls).set_index('Timestamp')
    c.to_csv(OUT/'met_matched_controls.csv',encoding='utf-8-sig')
    c[list(NAMES)].corr(method='spearman').to_csv(OUT/'met_feature_correlations.csv',encoding='utf-8-sig')
    rng=np.random.default_rng(SEED);boots={key:[] for key in NAMES};boot_ranks={key:[] for key in NAMES}
    for _ in range(1200):
        years=rng.choice(np.arange(2021,2026),5,replace=True)
        b=pd.concat([c[c.year.eq(y)] for y in years])
        zz={}
        for key in NAMES:
            x=b[key].dropna().values
            if len(x)<30:continue
            med=np.median(x);scale=1.4826*np.median(abs(x-med))
            # Zero-inflated rainfall: no arbitrary epsilon inflation.
            if scale<1e-8:continue
            z=(event[key]-med)/scale
            boots[key].append(z)
            if np.isfinite(z):zz[key]=abs(z)
        for rank,key in enumerate(sorted(zz,key=zz.get,reverse=True),1):boot_ranks[key].append(rank)
    rows=[]
    for key in NAMES:
        x=c[key].dropna().values
        if not len(x):continue
        med=np.median(x);scale=1.4826*np.median(abs(x-med))
        z=(event[key]-med)/scale if scale>=1e-8 else np.nan
        bs=np.asarray(boots[key]);lo,hi=np.quantile(bs,[.025,.975]) if len(bs)>30 else [np.nan,np.nan]
        ranks=np.array(boot_ranks[key]); rlo,rhi=np.quantile(ranks,[.025,.975]) if len(ranks) else [np.nan,np.nan]
        rows.append(dict(feature=key,name=NAMES[key],unit=UNITS[key],event_value=event[key],control_median=med,control_scale=scale,robust_z=z,abs_z=abs(z),z_lo=lo,z_hi=hi,empirical_percentile=(np.sum(x<event[key])+.5*np.sum(x==event[key]))/len(x)*100,n_control=len(x),rankable=bool(np.isfinite(z)),bootstrap_valid=len(bs),rank_lo=rlo,rank_hi=rhi,top5_bootstrap_probability=float(np.mean(ranks<=5)) if len(ranks) else np.nan))
    tab=pd.DataFrame(rows).sort_values('abs_z',ascending=False,na_position='last')
    tab['rank']=np.arange(1,len(tab)+1)
    tab.to_csv(OUT/'met_feature_ranking.csv',index=False,encoding='utf-8-sig')
    # Greedy nonredundant supplement preserves the requested raw top-five list.
    corr=c[list(NAMES)].corr(method='spearman');selected=[];cluster=[]
    for _,r in tab[tab.rankable].iterrows():
        matches=[s for s in selected if abs(corr.loc[r.feature,s])>=.85]
        representative=matches[0] if matches else r.feature
        if not matches:selected.append(r.feature)
        cluster.append(dict(feature=r.feature,name=r['name'],representative=representative,selected_nonredundant=not matches,absolute_spearman=abs(corr.loc[r.feature,representative]),threshold=.85))
    pd.DataFrame(cluster).to_csv(OUT/'met_feature_clusters.csv',index=False,encoding='utf-8-sig')
    f.loc['2026-08-12':'2026-08-29'].to_csv(OUT/'met_event_timeseries.csv',encoding='utf-8-sig')
    # Sensitivity to event antecedent aggregation windows.
    sens=[]
    for width in [6,12,24,48]:
        W=f[list(NAMES)].rolling(width,min_periods=int(np.ceil(.8*width))).mean()
        e=W.loc[STOP]
        C=W.reindex(c.index)
        for key in NAMES:
            v=C[key].dropna();med=v.median();s=1.4826*(v-med).abs().median()
            z=(e[key]-med)/s if s>1e-8 else np.nan
            sens.append(dict(window_h=width,feature=key,name=NAMES[key],robust_z=z,abs_z=abs(z)))
    pd.DataFrame(sens).to_csv(OUT/'met_window_sensitivity.csv',index=False,encoding='utf-8-sig')
    # Profiles for intermediate boundary-layer diagnosis, excluding all post-event hours.
    return tab

def trend_analysis():
    chunks=[]
    for p in sorted((ROOT/'data/dataset_2').glob('*.xlsx')):
        d=pd.read_excel(p);d=d.rename(columns={d.columns[0]:'Timestamp'});d.Timestamp=pd.to_datetime(d.Timestamp);chunks.append(d)
    d=pd.concat(chunks).sort_values('Timestamp').set_index('Timestamp');assert not d.index.duplicated().any()
    annual=d.resample('YS').agg(['mean','count'])
    rows=[]; annual_rows=[]
    for station in d:
        a=annual[station];valid=a['count']>=350; yy=a.index.year[valid].to_numpy();vv=a['mean'][valid].to_numpy()
        s,inter,lo,hi=stats.theilslopes(vv,yy,.95);tau,p=stats.kendalltau(yy,vv)
        rows.append(dict(station=station,n_years=len(yy),start_year=int(yy.min()),end_year=int(yy.max()),slope_C_decade=10*s,slope_lo=10*lo,slope_hi=10*hi,kendall_tau=tau,p_value=p))
        for t,r in a.iterrows():annual_rows.append(dict(year=t.year,station=station,mean_temperature=r['mean'],n_days=int(r['count']),full_year=bool(r['count']>=350)))
    pd.DataFrame(rows).to_csv(OUT/'met_temperature_trends.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(annual_rows).to_csv(OUT/'met_annual_temperature.csv',index=False,encoding='utf-8-sig')
    d.to_csv(OUT/'met_daily_temperature.csv',encoding='utf-8-sig')
    return dict(first=str(d.index.min()),last=str(d.index.max()),n_days=len(d),trends=rows,full_year_threshold=350)

def forecast_temperature(f):
    """CQR with strict chronological split and no future observation features."""
    X=pd.DataFrame(index=f.index)
    for lag in [0,1,3,6,12,24,48]:X['Tlag'+str(lag)]=f.T2.shift(lag)
    for var in ['RH2','P6','VWC10','Rn','WS20']:X[var]=f[var]
    hr=f.index.hour;day=f.index.dayofyear
    X['hr_sin']=np.sin(2*np.pi*hr/24);X['hr_cos']=np.cos(2*np.pi*hr/24)
    X['doy_sin']=np.sin(2*np.pi*day/365.2425);X['doy_cos']=np.cos(2*np.pi*day/365.2425)
    y=f.T2.shift(-6)
    # Split according to target time to avoid a six-hour boundary overlap.
    target_time=f.index+pd.Timedelta(hours=6)
    train=(target_time<pd.Timestamp('2024-01-01'))&y.notna()&X['Tlag0'].notna()
    cal=(target_time>=pd.Timestamp('2024-01-01'))&(target_time<pd.Timestamp('2025-01-01'))&y.notna()&X['Tlag0'].notna()
    test=(target_time>=pd.Timestamp('2025-01-01'))&(target_time<pd.Timestamp('2026-01-01'))&y.notna()&X['Tlag0'].notna()
    pred={}
    for q in [.025,.5,.975]:
        m=HistGradientBoostingRegressor(loss='quantile',quantile=q,max_iter=180,max_leaf_nodes=15,learning_rate=.06,min_samples_leaf=40,l2_regularization=1.,random_state=SEED)
        m.fit(X.loc[train],y.loc[train])
        pred[q]=dict(cal=m.predict(X.loc[cal]),test=m.predict(X.loc[test]))
    # Enforce quantile order by rearrangement, not by test-specific tuning.
    cp=np.sort(np.array([pred[q]['cal'] for q in [.025,.5,.975]]),axis=0)
    tp=np.sort(np.array([pred[q]['test'] for q in [.025,.5,.975]]),axis=0)
    score=np.maximum(cp[0]-y.loc[cal].values,y.loc[cal].values-cp[2])
    # Block maximum over nonoverlapping 24-hour issue-time blocks: conservative
    # daily simultaneous intervals; finite-sample guarantee requires exchangeability.
    ss=pd.Series(score,index=target_time[cal]);bs=ss.resample('D').agg(['max','count'])
    blocks=bs.loc[bs['count'].eq(24),'max']
    alpha=.05; k_order=int(np.ceil((len(blocks)+1)*(1-alpha)))
    if k_order>len(blocks):raise ValueError('Too few complete calibration blocks for finite conformal order statistic')
    correction=max(0,float(np.sort(blocks.to_numpy())[k_order-1]))
    lo=tp[0]-correction;hi=tp[2]+correction;truth=y.loc[test].values
    covered=(truth>=lo)&(truth<=hi)
    tab=pd.DataFrame(dict(issue_time=X.index[test],target_time=target_time[test],observed=truth,median=tp[1],raw_lower=tp[0],raw_upper=tp[2],lower=lo,upper=hi,covered=covered))
    tab.to_csv(OUT/'met_temperature_forecast.csv',index=False,encoding='utf-8-sig')
    db=tab.groupby(pd.to_datetime(tab.target_time).dt.date).covered.agg(['all','count'])
    daily=db.loc[db['count'].eq(24),'all']
    # Wilson interval on daily all-covered indicator; temporal dependence remains.
    n=len(daily);k=daily.sum();z=1.95996398454;ph=k/n
    center=(ph+z*z/(2*n))/(1+z*z/n);half=z*np.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/(1+z*z/n)
    result=dict(target='station six-hour-ahead 2 m air temperature; NOT debris-flow initiation',model='HistGradientBoosting quantile regression + nonoverlapping daily-block split conformal',train_years='2021–2023',calibration_year='2024',test_year='2025',horizon_h=6,alpha=alpha,seed=SEED,train_n=int(train.sum()),calibration_n=int(cal.sum()),calibration_blocks=len(blocks),calibration_order_statistic=k_order,calibration_block_definition='target calendar day with exactly 24 valid forecast pairs; maximum nonconformity',test_n=int(test.sum()),test_blocks=n,conformal_correction_C=correction,temperature_MAE_C=mean_absolute_error(truth,tp[1]),persistence_MAE_C=mean_absolute_error(truth,X.loc[test,'Tlag0']),raw_point_coverage=float(((truth>=tp[0])&(truth<=tp[2])).mean()),point_coverage=float(covered.mean()),daily_simultaneous_coverage=float(daily.mean()),daily_coverage_wilson_95=[center-half,center+half],mean_width_C=float(np.mean(hi-lo)),parameters=dict(max_iter=180,max_leaf_nodes=15,learning_rate=.06,min_samples_leaf=40,l2_regularization=1.),caution='Temporal dependence/nonstationarity can invalidate exchangeability; observed retrospective coverage only. Wilson interval assumes independent daily indicators, so is a descriptive binomial approximation, not dependence-robust. No disaster time coverage or warning lead time can be estimated from this experiment.')
    return result

def main():
    d,audit=load_hourly();f=engineer(d)
    f.to_csv(OUT/'met_hourly_features.csv',encoding='utf-8-sig')
    d.loc['2026-08-25':'2026-08-26 10:00',[c for c in d if c.startswith(('Ta_','WS_','WD_'))]].to_csv(OUT/'met_event_profiles.csv',encoding='utf-8-sig')
    ranking=event_comparison(f);trend=trend_analysis();forecast=forecast_temperature(f)
    pre=f.loc[STOP-pd.Timedelta(hours=71):STOP]
    # Restrict general climatology to historical, actually usable observations.
    clim=f.loc[:'2025-12-31'].groupby([f.loc[:'2025-12-31'].index.month,f.loc[:'2025-12-31'].index.hour]).median()
    clim.index.names=['month','hour'];clim.to_csv(OUT/'met_climatology.csv',encoding='utf-8-sig')
    summary=dict(n_hourly_rows=len(d),calendar_start=str(d.index.min()),calendar_end=str(d.index.max()),event_time_stated=str(EVENT),event_issue_stop=str(STOP),time_zone='not supplied; timestamps treated as local labels, no conversion',qc_policy='numeric coercion; abs>=9990 missing; QC==0 only when available; conservative physical limits; no imputation for event ranking; rolling rain requires every hour present',last_valid_selected=audit[audit.variable.isin(['Precip(mm)','Ta_2m(degree C)','H(W/m2)','VWC_0.1m(m3/m3)'])].to_dict('records'),event_P72_mm=float(f.loc[STOP,'P72']),event_P24_mm=float(f.loc[STOP,'P24']),top5=ranking[ranking.rankable].head(5).replace({np.nan:None}).to_dict('records'),ranking_protocol=dict(window_h=24,min_valid_h=20,control_years=[2021,2022,2023,2024,2025],matched_calendar_days=31,control_hour=10,n_max=155,bootstrap_year_clusters=1200,seed=SEED,metric='absolute robust standardized difference: (event trailing-24h mean − control median) / (1.4826 × control MAD)',interpretation='descriptive single-event meteorological anomaly association; no causal or population-level disaster attribution'),temperature_history=trend,forecast=forecast,unidentifiable=['debris-flow event-time 95% confidence/prediction interval','independent disaster-event interval coverage','operational disaster-warning lead time','spatial warning radius from one station alone'],limitations=['QC codebook and station coordinates/elevation/footprint metadata not supplied','1–20 m profiles characterize surface layer only, not complete boundary-layer height','no inventory of dated independent positive/negative debris-flow events','station rainfall is not precipitation at the high-elevation source zone'])
    (OUT/'met_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,default=plain),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2,default=plain))

if __name__=='__main__':main()
