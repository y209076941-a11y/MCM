#!/usr/bin/env python3
"""Auditable publication-style visualizations; only reads computed result files.

Run after met_analysis.py, geo_analysis.py and simulation.py. Set
SIMSUN_FONT_FILE=/path/to/licensed/simsun.ttf to switch all figure text.
Every figure is saved separately as transparent RGBA TIFF (600 dpi, LZW),
EPS (vector, no background rectangle; EPS has no alpha channel), and PNG.
"""
from __future__ import annotations
import os, sys, json, warnings
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'figures'/'.mplconfig'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.colors import LinearSegmentedColormap, Normalize, LogNorm
from matplotlib.font_manager import FontProperties, fontManager
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from PIL import Image

OUT=ROOT/'figures';RES=ROOT/'results';OUT.mkdir(exist_ok=True)
FONT=os.getenv('SIMSUN_FONT_FILE',str(ROOT/'data'/'NotoSerifCJKsc-Regular.ttf'))
fontManager.addfont(FONT);FAMILY=FontProperties(fname=FONT).get_name()
plt.rcParams.update({'font.family':FAMILY,'font.size':15,'axes.titlesize':17,
 'axes.labelsize':15,'xtick.labelsize':14.5,'ytick.labelsize':14.5,
 'legend.fontsize':14.5,'figure.titlesize':18,'axes.unicode_minus':False,
 'figure.facecolor':'none','axes.facecolor':'none','savefig.facecolor':'none',
 'axes.edgecolor':'#344B58','axes.labelcolor':'#344B58','text.color':'#344B58',
 'xtick.color':'#344B58','ytick.color':'#344B58','axes.linewidth':.8,
 'lines.linewidth':1.7,'pdf.fonttype':42,'ps.fonttype':3,
 'figure.constrained_layout.use':True,'figure.constrained_layout.h_pad':.10,
 'figure.constrained_layout.w_pad':.08,'axes.spines.top':False,'axes.spines.right':False,
 'image.interpolation':'none','image.composite_image':False})
C=['#7BA8BA','#C7909A','#90AD93','#B09DC4','#D0AF79','#7DAEB0']
INK='#344B58'
CM=LinearSegmentedColormap.from_list('mist',['#F8FAF4','#C9DECD','#9BC1BA','#7F9DAE'])
CR=LinearSegmentedColormap.from_list('rose',['#FCF8F1','#E4D4B6','#D1A6AA','#AF7E96'])
CB=LinearSegmentedColormap.from_list('ice',['#F6FAFC','#CADFEA','#8EB5CB','#628DA9'])
DIV=LinearSegmentedColormap.from_list('balance',['#8DB5C8','#DAE8EE','#FCFAF5','#EAD7C6','#C8919C'])
MAN=[]

def clean(ax):
    ax.tick_params(direction='out',length=3.5,pad=5)
    ax.set_facecolor('none');ax.grid(False)
    return ax

def panel(ax,label):
    ax.set_title(label,loc='left',pad=12)

def save(fig,stem,section,title,caption,interpretation):
    # Source width is 6.6in. At manuscript6.4in, 15pt labels remain14.5pt.
    for ax in fig.axes:
        clean(ax)
    for txt in fig.findobj(matplotlib.text.Text):
        if txt.get_text() and txt.get_fontsize()<14.5:txt.set_fontsize(14.5)
    fig.patch.set_alpha(0)
    png=OUT/f'{stem}.png';tif=OUT/f'{stem}.tiff';eps=OUT/f'{stem}.eps'
    fig.savefig(png,dpi=180,transparent=True,pad_inches=.04)
    fig.savefig(tif,dpi=600,transparent=True,pad_inches=.04,
                pil_kwargs={'compression':'tiff_lzw'})
    fig.savefig(eps,dpi=600,transparent=True,pad_inches=.04)
    with Image.open(tif) as im:
        assert im.mode=='RGBA',(stem,im.mode)
        assert abs(im.info['dpi'][0]-600)<1
    MAN[:]=[r for r in MAN if r['stem']!=stem]
    MAN.append({'file':str(png.relative_to(ROOT)),'stem':stem,'section':section,
                'title':title,'caption':caption,'interpretation':interpretation,
                'tiff':str(tif.relative_to(ROOT)),'eps':str(eps.relative_to(ROOT)),
                'source_width_in':float(fig.get_figwidth()),'font_min_pt':14.5,
                'dpi':600,'transparent_tiff':True})
    plt.close(fig)
    (RES/'figure_manifest.json').write_text(json.dumps(MAN,ensure_ascii=False,indent=2))
    print('SAVED',stem,flush=True)

def plot_met():
    if not (RES/'met_summary.json').exists():return
    s=json.loads((RES/'met_summary.json').read_text())
    audit=pd.read_csv(RES/'met_variable_audit.csv')
    sel=['Ta_2m(degree C)','Precip(mm)','WS_20m(m/s)','Rsd(W/m2)','Rld(W/m2)',
         'VWC_0.1m(m3/m3)','VWC_0.4m(m3/m3)','soilT_0.1m(degree C)',
         'H(W/m2)','LE(W/m2)','USTAR(m/s)','TKE(m2/s2)']
    a=audit.set_index('variable').loc[sel].reset_index()
    names=['2米气温','逐小时降雨','20米风速','入射短波辐射','入射长波辐射',
           '10厘米土壤含水率','40厘米土壤含水率','10厘米土壤温度',
           '感热通量','潜热通量','摩阻速度','湍动能']
    fig,ax=plt.subplots(figsize=(6.6,6.5));yy=np.arange(len(a))
    cols=[dict(MET=C[0],RADM=C[4],SOIL=C[2],FLUX=C[3])[k] for k in a.kind]
    ax.barh(yy,a.missing_pct,color=cols,height=.61)
    ax.set_yticks(yy,names);ax.invert_yaxis();ax.set_xlim(0,max(a.missing_pct)*1.24)
    for y,v in zip(yy,a.missing_pct):ax.text(v+.8,y,f'{v:.1f}%',va='center')
    ax.set_xlabel('质量控制后缺测比例（%）');panel(ax,'观测可用性：逐变量核查')
    fig.legend(handles=[Line2D([0],[0],color=c,lw=6,label=l) for l,c in [('MET',C[0]),('RADM',C[4]),('SOIL',C[2]),('FLUX',C[3])]],
              frameon=False,ncol=4,loc='outside lower center',borderaxespad=.3)
    save(fig,'F01_观测可用性','audit','观测可用性与质量控制结果',
         '四类小时观测经数值缺测标记、质量标识和物理范围筛选后的缺测比例。每个原始变量均对应52,584个小时位置；全年日历网格不等于全年有效观测。',
         f'气温和降水缺测比例约11.1%，感热通量缺测比例为31.7%。通量数据稀疏性高于气象梯度资料，不能将缺测值补成零并解释为弱湍流。事件排序采用有效小时约束，避免填补结果主导关联性。')

    annual=pd.read_csv(RES/'met_annual_temperature.csv');tr=pd.read_csv(RES/'met_temperature_trends.csv')
    annual=annual[annual.full_year==True]
    p=annual.pivot(index='station',columns='year',values='mean_temperature').reindex(tr.station)
    anomalies=p.sub(p.mean(axis=1),axis=0)
    fig,(ax,bx)=plt.subplots(2,1,figsize=(6.6,7.4),gridspec_kw={'height_ratios':[1.2,1]})
    im=ax.imshow(anomalies,aspect='auto',cmap=DIV,vmin=-2,vmax=2)
    ax.set_yticks(range(5),tr.station);ax.set_xticks([0,5,10,15,19],['2005','2010','2015','2020','2024'])
    ax.set_xlabel('年份');panel(ax,'a  县域年均气温距平')
    cb=fig.colorbar(im,ax=ax,orientation='horizontal',shrink=.8,pad=.18,fraction=.08);cb.set_label('相对各县2005—2024均值（℃）')
    yy=np.arange(5)
    bx.errorbar(tr.slope_C_decade,yy,xerr=np.array([tr.slope_C_decade-tr.slope_lo,tr.slope_hi-tr.slope_C_decade]),
                fmt='o',color=C[0],ecolor=C[0],capsize=4,ms=6)
    bx.axvline(0,color=INK,lw=.8,ls='--');bx.set_yticks(yy,tr.station);bx.invert_yaxis()
    bx.set_xlabel('Theil–Sen趋势及95%区间（℃/10年）');panel(bx,'b  趋势方向与不确定性')
    save(fig,'F02_长期温度背景','q1','长期气温背景与稳健趋势',
         '上图展示县域年均气温相对各自长期均值的距平，下图展示Theil–Sen趋势及95%区间。2025年只覆盖至8月2日，未与完整年度混合估计趋势。',
         '五县2005—2024年完整年序列趋势均为正，但95%区间均跨零。吉隆县趋势为0.130℃/10年，不能据此声称存在显著单调增温，更不能将这一长期背景直接等同于2026年特定冰崩的原因。')

    ev=pd.read_csv(RES/'met_event_timeseries.csv',parse_dates=['Timestamp']).set_index('Timestamp')
    ev=ev.loc['2026-08-22':'2026-08-26 10:00']
    fig,axs=plt.subplots(3,1,figsize=(6.6,8.0),sharex=True)
    for ax,col,label,c in zip(axs,['T2','P72','VWC40'],['2米气温（℃）','72小时累计降雨（mm）','40厘米含水率（m³/m³）'],C):
        ax.plot(ev.index,ev[col],color=c)
        ax.axvline(pd.Timestamp('2026-08-26 10:30'),ls='--',color=INK,lw=1)
        ax.set_ylabel(label)
    axs[1].set_ylim(-.2,max(1,float(ev.P72.max())*1.2))
    panel(axs[0],'灾前过程：测站气温、水分与降雨')
    axs[-1].xaxis.set_major_locator(mdates.DayLocator(interval=1));axs[-1].xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
    axs[-1].set_xlabel('2026年日期（原始时间标签）')
    axs[1].text(.30,.88,'事件前72小时\n本站累计降雨为0 mm',transform=axs[1].transAxes,va='top')
    save(fig,'F03_灾前气象过程','q1','事件前气象—土壤水分过程',
         '只使用2026年8月26日10:00及之前的数据，虚线标记题面给出的10:30事件时刻。测站位置与高位冰崩源区并不等同。',
         '灾前气温表现出明显日变化，深层土壤含水率变化相对平缓；事件前72小时测站降雨总量为零。这反驳了以本站观测作为“灾前暴雨峰值”证据的做法，但不能排除源区局地降水、融水或冰崩冲击。')

    prof=pd.read_csv(RES/'met_event_profiles.csv',parse_dates=['Timestamp'])
    fig,(ax,bx)=plt.subplots(1,2,figsize=(6.6,4.8),sharey=True)
    z=np.array([1,2,4,10,20])
    for hour,c in zip([0,6,10],C):
        row=prof.loc[prof.Timestamp==pd.Timestamp(f'2026-08-26 {hour:02}:00')]
        if not len(row):continue
        r=row.iloc[0]
        tt=[r[f'Ta_{i}m(degree C)'] for i in z]
        uu=[r[f'WS_{i}m(m/s)'] for i in z]
        ax.plot(tt,z,'o-',color=c,label=f'{hour:02}:00',ms=4)
        bx.plot(uu,z,'o-',color=c,label=f'{hour:02}:00',ms=4)
    ax.set_ylabel('测量高度（m）');ax.set_xlabel('气温（℃）');bx.set_xlabel('风速（m/s）')
    ax.set_yticks([1,4,10,20]);panel(ax,'a  温度廓线');panel(bx,'b  风速廓线')
    fig.legend(*ax.get_legend_handles_labels(),loc='outside lower center',ncol=3,frameon=False)
    save(fig,'F04_近地层垂直结构','q1','近地层温度与风速垂直结构',
         '2026年8月26日00:00、06:00和10:00的1—20米原始梯度观测。高度范围属于近地表层，不能推断整个大气边界层顶高度。',
         '同一日期不同时刻廓线形状存在差异，显示日内热力分层与动力剪切的共同调制。由于最高观测高度只有20米，论文将这些证据限定为近地层结构，避免把有限高度梯度外推为完整边界层结构。')

    rank=pd.read_csv(RES/'met_feature_ranking.csv');r=rank[rank.rankable==True].head(5).copy()
    fig,ax=plt.subplots(figsize=(6.6,5.0));yy=np.arange(5)
    for i,row in r.reset_index(drop=True).iterrows():
        ax.plot([row.z_lo,row.z_hi],[i,i],color=C[i],lw=2)
        ax.plot(row.robust_z,i,'o',color=C[i],ms=7)
    ax.set_xscale('symlog',linthresh=3);ax.set_xlim(-1,16);ax.set_xticks([-1,0,1,2,3,5,10,15],['−1','0','1','2','3','5','10','15'])
    ax.set_yticks(yy,[f'{n}\n历史分位{p:.1f}%' for n,p in zip(r.name,r.empirical_percentile)])
    ax.invert_yaxis();ax.axvline(0,color=INK,ls='--',lw=.8)
    ax.set_xlabel('稳健标准化差异及95%年簇自助区间')
    panel(ax,'五项最高异常关联：不确定性不可忽略')
    save(fig,'F05_前五异常关联','q1','事件条件下的前五项气象异常关联',
         '点为事件前24小时均值相对历史匹配窗口的稳健标准化差异；线为1,200次按年份成簇自助区间。横轴超过3的部分采用对称对数压缩，避免深层含水率宽区间掩盖其他特征。',
         '按绝对稳健差异排序依次为40厘米土壤含水率、2米气温、24小时正积温、净辐射、72小时正积温。深层土壤水分虽然点估计居首，但区间跨零且很宽，排名稳定性弱；气温和积温证据更稳定。排序仅描述单次事件的异常关联，不代表因果贡献或总体灾害预测重要性。')

    sens=pd.read_csv(RES/'met_window_sensitivity.csv');features=list(r.feature)+['H','LE','TKE']
    pv=sens.pivot(index='feature',columns='window_h',values='robust_z').reindex(features)
    fig,ax=plt.subplots(figsize=(6.6,5.6));im=ax.imshow(pv,aspect='auto',cmap=DIV,vmin=-3,vmax=3)
    nmap=rank.set_index('feature')['name'].to_dict();ax.set_yticks(range(len(pv)),[nmap.get(i,i) for i in pv.index]);ax.set_xticks(range(len(pv.columns)),pv.columns)
    ax.set_xlabel('灾前平均窗口长度（h）');panel(ax,'时间尺度敏感性：异常不等于固定排名')
    for j in range(pv.shape[0]):
        for k in range(pv.shape[1]):
            v=pv.iloc[j,k]
            if np.isfinite(v):ax.text(k,j,f'{v:.1f}',ha='center',va='center',fontsize=14.5,color=INK)
    cb=fig.colorbar(im,ax=ax,orientation='horizontal',pad=.14,fraction=.06);cb.set_label('稳健标准化差异')
    save(fig,'F06_关联尺度敏感性','q1','前兆关联对时间窗口的敏感性',
         '对6、12、24和48小时窗口分别重新匹配历史样本并计算稳健标准化差异，颜色和数值同时编码异常方向与幅度。',
         '不同物理量具有不同响应时间。温度、积温与净辐射的异常应结合持续时间解释；深层水分的背景差异并不等价于临灾瞬时跃迁。多尺度图用于检查24小时排名是否依赖单一窗口，而不是追加独立显著性证据。')

    f=pd.read_csv(RES/'met_temperature_forecast.csv',parse_dates=['target_time']).set_index('target_time').loc['2025-07-15':'2025-07-19 23:00']
    fig,ax=plt.subplots(figsize=(6.6,5.0))
    # Solid light polygon rather than alpha, so EPS and TIFF stay consistent.
    ax.fill_between(f.index,f.lower,f.upper,color='#E2EBF0',label='块保形区间')
    ax.plot(f.index,f.observed,color=INK,label='实测气温',lw=1.35)
    ax.plot(f.index,f['median'],color=C[1],label='6小时超前预测',lw=1.5)
    ax.xaxis.set_major_locator(mdates.DayLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
    ax.set_xlabel('2025年日期');ax.set_ylabel('2米气温（℃）');panel(ax,'独立年份验证：气温代理预测')
    fig.legend(*ax.get_legend_handles_labels(),frameon=False,ncol=1,loc='outside lower center')
    save(fig,'F07_气温代理区间预测','q3','六小时超前气温代理区间预测',
         '使用2021—2023年训练、2024年日块校准和2025年独立测试。此处展示2025年7月15—19日的实测、预测中位数与校准区间，预测对象为测站气温，不是泥石流发生时间。',
         f'全年测试平均绝对误差为{s["forecast"]["temperature_MAE_C"]:.3f}℃。保形校准明显拓宽区间，体现覆盖可靠性与区间精度之间的取舍；不能把气温预测区间换名为灾害触发时间区间。')

    q=s['forecast'];fig,(ax,note)=plt.subplots(2,1,figsize=(6.6,5.6),gridspec_kw={'height_ratios':[4,.8]})
    vals=np.array([q['raw_point_coverage'],q['point_coverage'],q['daily_simultaneous_coverage']])*100
    xx=np.arange(3);ax.bar(xx,vals,color=[C[1],C[0],C[2]],width=.57)
    lo,hi=np.array(q['daily_coverage_wilson_95'])*100
    ax.errorbar(2,vals[2],yerr=[[vals[2]-lo],[hi-vals[2]]],fmt='none',color=INK,capsize=4)
    ax.axhline(95,color=INK,lw=.9,ls='--');ax.set_ylim(0,118)
    for x,v in zip(xx,vals):ax.text(x,v+7,f'{v:.2f}%',ha='center')
    ax.set_xticks(xx,['原始逐点','校准逐点','校准日块']);ax.set_ylabel('实测覆盖率（%）')
    panel(ax,'覆盖与锐度：独立测试而非训练拟合')
    note.set_axis_off()
    note.text(.0,.5,f'平均区间宽度 {q["mean_width_C"]:.2f}℃\n独立完整日 {q["test_blocks"]}；超前量 6小时',transform=note.transAxes,va='center')
    save(fig,'F08_代理预测校准诊断','q3','气温代理预测的覆盖率与区间锐度',
         '虚线为95%名义覆盖率，误差线为日块实测覆盖率的Wilson区间。逐点覆盖与整日所有目标同时被覆盖是不同统计对象，不能混报。',
         f'原始逐点覆盖率为{vals[0]:.2f}%，校准后为{vals[1]:.2f}%；日块同时覆盖率为{vals[2]:.2f}%，95%区间为[{lo:.2f}%，{hi:.2f}%]。平均区间宽度{q["mean_width_C"]:.2f}℃说明高覆盖以较宽区间为代价；时间相关和分布漂移仍限制理论保证。')

def plot_geo():
    if not (RES/'geo_grid.npz').exists():return
    d=np.load(RES/'geo_grid.npz');s=json.loads((RES/'geo_summary.json').read_text())
    x,y=d['x']/1000,d['y']/1000
    extent=[x.min()-.1,x.max()+.1,y.min()-.1,y.max()+.1]
    b=pd.read_csv(RES/'geo_boundaries.csv')
    def bounds(ax):
        for _,g in b.groupby('basin_id'):
            if not ((g.x/1000).between(extent[0],extent[1])&(g.y/1000).between(extent[2],extent[3])).any():continue
            ax.plot(g.x/1000,g.y/1000,color='#9F777D',lw=.65)
        ax.set_xlim(extent[:2]);ax.set_ylim(extent[2:])
        ax.xaxis.set_major_locator(MaxNLocator(4));ax.yaxis.set_major_locator(MaxNLocator(4))
        ax.set_xlabel('UTM 45N东坐标（km）');ax.set_ylabel('UTM 45N北坐标（km）')
        ax.text(.94,.94,'北',ha='center',transform=ax.transAxes)
        ax.annotate('',xy=(.94,.92),xytext=(.94,.80),xycoords='axes fraction',arrowprops={'arrowstyle':'->','color':INK,'lw':1})
    fig,ax=plt.subplots(figsize=(6.6,5.7))
    im=ax.imshow(np.ma.masked_where(~d['mask'],d['z']),extent=extent,cmap=CM,origin='upper',interpolation='none')
    bounds(ax);panel(ax,'真实地形与历史沟域：覆盖范围先于建模')
    cb=fig.colorbar(im,ax=ax,orientation='horizontal',pad=.17,fraction=.06);cb.set_label('高程（m）')
    fig.legend(handles=[Line2D([0],[0],color='#9F777D',label='历史沟域边界')],frameon=False,loc='outside lower center')
    save(fig,'F09_地形与历史沟域','q2','地形与历史灾害沟域覆盖关系',
         '原始DEM由经纬度投影至UTM 45N并统一为200米计算网格，线条为历史沟域边界。DEM采集时期未知，不能将其直接作为独立灾前地形证据。',
         f'有效DEM面积为{s["grid"]["dem_area_km2"]:.2f}平方千米，84条历史沟域中只有23条与该网格相交。地形中位坡度为{s["grid"]["slope_degree"]["median"]:.2f}°，95%分位为{s["grid"]["slope_degree"]["p95"]:.2f}°。空间样本实际支持范围小于全部资料覆盖范围，不能把未覆盖地区填成低风险。')

    fig,ax=plt.subplots(figsize=(6.6,5.7))
    score=d['score'];im=ax.imshow(np.ma.masked_invalid(score),extent=extent,cmap=CR,vmin=0,vmax=1,origin='upper')
    bounds(ax);panel(ax,'历史流域成员评分（非发生概率）')
    cb=fig.colorbar(im,ax=ax,orientation='horizontal',pad=.17,fraction=.06);cb.set_label('经正则化Logistic估计的成员评分')
    save(fig,'F10_历史流域成员评分','q2','历史流域成员评分的空间分布',
         '评分模型区分已编录沟域成员与有缓冲隔离的未标注背景，采用地形与土地覆盖联合特征。空白区域表示缺少完整联合数据，并非零风险。',
         f'DEM与土地覆盖共同有效面积为{s["grid"]["landcover_overlap_area_km2"]:.2f}平方千米。训练采用平衡案例—背景抽样，因此输出数值的总体概率含义受抽样和漏编录影响；本图用于相对排查优先级，不用于发布某地点的灾害发生概率。')

    cv=pd.read_csv(RES/'geo_cv_metrics.csv')
    fig,(ax,bx)=plt.subplots(2,1,figsize=(6.6,6.5),sharex=True)
    labels={'logistic':'正则化Logistic','extratrees':'极端随机树'}
    for model,c,mark in [('logistic',C[0],'o'),('extratrees',C[1],'s')]:
        g=cv[cv.model==model].sort_values('fold')
        ax.plot(g.fold+1,g.auc,'-',marker=mark,color=c,label=labels[model],ms=6)
        bx.plot(g.fold+1,g.average_precision,'-',marker=mark,color=c,ms=6)
    ax.set_ylim(.58,.82);bx.set_ylim(.48,.91)
    ax.set_ylabel('AUROC');bx.set_ylabel('平均精确率（AP）');bx.set_xlabel('空间隔离验证折')
    bx.set_xticks([1,2,3,4]);panel(ax,'a  空间外推判别能力');panel(bx,'b  精确率受验证集构成影响')
    ax.legend(frameon=False,loc='lower left')
    ax.text(.99,.96,'2 km隔离缓冲；完整沟域分组',ha='right',va='top',transform=ax.transAxes)
    means=cv.groupby('model').auc.mean()
    save(fig,'F11_空间交叉验证','q2','带缓冲隔离的空间交叉验证',
         '按纬向空间带划分四折，完整沟域按中心归组，并移除距测试样本2千米以内的训练点。模型选择与性能估计共用这四折，结果属于探索性比较。',
         f'正则化Logistic四折平均AUROC为{means["logistic"]:.3f}，极端随机树为{means["extratrees"]:.3f}。复杂树模型未带来稳定空间迁移优势；第4折性能下降说明场景差异显著。AP受到不同验证折成员比例影响，不能直接解释为真实发生风险校准效果。')

    g=np.load(RES/'geo_glacier.npz');xx,yy=g['x']/1000,g['y']/1000
    ex=[xx.min()-.015,xx.max()+.015,yy.min()-.015,yy.max()+.015]
    fig,axs=plt.subplots(2,1,figsize=(6.6,8.4))
    for ax,key,title,lab,cmap in zip(axs,['thickness','velocity'],['a  冰厚：物质储量背景','b  表面速度：多年动力背景'],['冰厚（m）','表面速度（m/年）'],[CB,CR]):
        arr=np.ma.masked_where(~g['mask']|~np.isfinite(g[key]),g[key])
        im=ax.imshow(arr,extent=ex,cmap=cmap,origin='upper',interpolation='none')
        ax.set_xlabel('UTM 45N东坐标（km）');ax.set_ylabel('北坐标（km）');panel(ax,title)
        ax.xaxis.set_major_locator(MaxNLocator(4));ax.yaxis.set_major_locator(MaxNLocator(3))
        cb=fig.colorbar(im,ax=ax,pad=.025,fraction=.06);cb.set_label(lab)
    save(fig,'F12_冰川物质动力背景','q2','冰川物质储量与多年动力背景',
         '冰川网格分辨率为30米，冰厚与表面速度按原始掩膜显示。速度是2014—2024年多年背景量，不能作为2026年临灾加速证据。',
         '冰川物质储量图用于限定情景释放源区，而不是将全部冰体体积当作真实崩落体积。厚冰区与高速度区的空间对应仅构成动力学背景；若要判断冰崩临界失稳，还必须补充时序位移、裂隙演化、床面条件与可校准的失稳事件。')

    if (RES/'trigger_critical_slope.csv').exists():
        cr=pd.read_csv(RES/'trigger_critical_slope.csv');ii=pd.read_csv(RES/'trigger_intensity_duration.csv');ts=json.loads((RES/'trigger_summary.json').read_text())
        fig,(ax,bx)=plt.subplots(2,1,figsize=(6.6,7.2))
        ax.plot(cr.slope_deg,cr.critical_m,color=C[0],lw=2)
        ax.axhline(0,color=INK,ls='--',lw=.8);ax.axhline(1,color=INK,ls='--',lw=.8)
        ax.set_xlabel('坡角（°）');ax.set_ylabel('临界相对饱和度');ax.set_ylim(-.3,1.5)
        panel(ax,'a  力学条件约束的临界水分')
        for beta,c in zip([25,28,30],C):
            cc=ii[ii.slope_deg==beta]
            bx.plot(cc.duration_h,cc.critical_intensity_mmh,color=c,label=f'坡角{beta}°')
        bx.axhline(20,color=INK,ls='--',lw=.8)
        bx.set_xscale('log');bx.set_xticks([1,6,24,72],['1','6','24','72'])
        bx.set_xlabel('持续时间（h）');bx.set_ylabel('临界雨强（mm/h）');bx.set_ylim(0,23)
        panel(bx,'b  线性蓄水推导的强度—历时关系')
        fig.legend(*bx.get_legend_handles_labels(),frameon=False,ncol=3,loc='outside lower center')
        save(fig,'F13_触发临界条件情景','q2','力学—水文耦合的触发临界条件情景',
             '浅层无限边坡与线性蓄水方程联立，黏聚力2千帕、内摩擦角32°、层厚1.5米、初始相对饱和度0.35、蓄水衰减时间72小时。图示为给定参数的情景阈值，并非由实测灾害校准所得。',
             f'在坡角30°时临界相对饱和度为{ts["cases"][2]["m_critical"]:.3f}，24小时临界恒定雨强为{ts["cases"][2]["I24_mmh"]:.2f}毫米/小时。坡度越大，达到失稳的增量水分越少；较陡情景甚至初始已失稳。由此可解释统一经验雨量阈值忽略地形与材料差异的局限，但这些土体参数不适用于直接判定高位冰崩断裂。')

    if (RES/'geo_landcover_transition.csv').exists():
        trans=pd.read_csv(RES/'geo_landcover_transition.csv')
        a0=trans.groupby('from_code').area_km2.sum().reindex(range(1,11),fill_value=0)
        a1=trans.groupby('to_code').area_km2.sum().reindex(range(1,11),fill_value=0)
        off=trans[trans.from_code!=trans.to_code].sort_values('area_km2',ascending=False)
        changed=float(off.area_km2.sum());total=float(trans.area_km2.sum());top=off.head(5)
        fig,(ax,bx)=plt.subplots(2,1,figsize=(6.6,7.3),gridspec_kw={'height_ratios':[1,1.1]})
        x=np.arange(10)
        ax.bar(x-.18,a0,color=C[0],width=.35,label='2020年')
        ax.bar(x+.18,a1,color=C[4],width=.35,label='2023年')
        ax.set_yscale('log');ax.set_ylim(.1,8000)
        ax.set_yticks([1,10,100,1000],['1','10','100','1000'])
        ax.set_xticks(x,range(1,11));ax.set_xlabel('土地覆盖分类编码');ax.set_ylabel('面积（km²，对数轴）')
        panel(ax,'a  共同有效区域的类别构成')
        fig.legend(*ax.get_legend_handles_labels(),frameon=False,ncol=2,loc='outside lower center')
        yy=np.arange(len(top));bx.barh(yy,top.area_km2,color=C[2],height=.58)
        bx.set_yticks(yy,[f'编码{int(a)} → 编码{int(b)}' for a,b in zip(top.from_code,top.to_code)])
        bx.invert_yaxis();bx.set_xlim(0,145)
        for y,v in zip(yy,top.area_km2):bx.text(v+2,y,f'{v:.1f}',va='center')
        bx.set_xlabel('转移面积（km²）');panel(bx,f'b  主要编码转移：总变化占比{100*changed/total:.2f}%')
        save(fig,'F17_土地覆盖变化','q2','土地覆盖编码构成与主要转移',
             f'只在2020与2023共同有效的{total:.2f}平方千米区域内比较面积，避免边缘有效掩膜变化被误计为土地覆盖变化。类别图例未随附件提供，因此保留编码1—10，不擅自命名类别。',
             f'共同有效范围内变化面积为{changed:.2f}平方千米，占{100*changed/total:.2f}%。最大的编码转移为7→4（{top.iloc[0].area_km2:.2f}平方千米），其次为5→4和4→5。该结果支持对下垫面变化进行分区核查，但没有类别释义和误差矩阵时，不能进一步宣称植被退化、冰川消融或建筑扩张的具体面积。')

def plot_sim():
    if not (RES/'sim_fields.npz').exists():return
    d=np.load(RES/'sim_fields.npz');s=json.loads((RES/'sim_summary.json').read_text())
    if 'full shallow-layer momentum' not in s['meta']['model']:
        raise RuntimeError('Withdrawn preliminary solver outputs: run final full-momentum simulation.py first.')
    sx,sy=d['source_xy'];xx=(d['x']-sx)/1000;yy=(d['y']-sy)/1000
    ds=float(d['cellsize'])/2000;ext=[xx.min()-ds,xx.max()+ds,yy.min()-ds,yy.max()+ds]
    times=d['snapshot_times'];sn=d['snapshots']
    fig,axs=plt.subplots(2,2,figsize=(6.6,7.1),sharex=True,sharey=True)
    vmax=float(np.nanmax(sn));norm=LogNorm(.1,10*np.ceil(vmax/10))
    for ax,target in zip(axs.ravel(),[0,120,300,600]):
        k=int(np.argmin(np.abs(times-target)));arr=np.ma.masked_where(sn[k]<.1,sn[k])
        ax.contour(xx,yy,d['z'],levels=np.arange(2500,7500,500),colors=['#C9D9D1'],linewidths=.55)
        im=ax.imshow(arr,extent=ext,origin='upper',cmap=CR,norm=norm)
        ax.plot(0,0,'+',color=INK,ms=7,mew=1)
        ax.set_title(f'模拟{times[k]:.0f}秒',loc='left',pad=8)
        ax.set_xlim(-4.5,4.5);ax.set_ylim(-4.5,4.5);ax.set_xticks([-3,0,3]);ax.set_yticks([-3,0,3])
        ax.set_aspect('equal')
    fig.supxlabel('相对释放源东西距离（km）',fontsize=15)
    fig.supylabel('相对释放源南北距离（km）',fontsize=15)
    cb=fig.colorbar(im,ax=axs,orientation='horizontal',pad=.07,shrink=.85,fraction=.05)
    cb.set_ticks([.1,1,10,50],labels=['0.1','1','10','50']);cb.set_label('混合层厚度（m，对数色标；≥0.1 m）')
    save(fig,'F14_泥石流情景演化','q4','真实地形上的浅层流情景演化',
         '基准情景采用冰厚比例0.20、库仑摩擦系数0.15、湍阻系数1,000米/秒²、150米网格和600秒模拟时长。全动量守恒格式保留动量平流，十字为算法选定释放源，等高线来自实际DEM。',
         f'等效初始体积为{s["reference_scenario"]["initial_volume_m3"]/1e6:.3f}百万立方米，模拟最大覆盖面积为{s["reference_scenario"]["footprint_km2"]:.3f}平方千米，峰值速度为{s["reference_scenario"]["peak_speed_ms"]:.2f}米/秒。图展示守恒求解器在真实地形上的传播和滞留过程，不能解释为对2026年灾害淹没范围的重建。')

    fig,(ax,bx)=plt.subplots(2,1,figsize=(6.6,8.0),sharex=True,sharey=True)
    for a in [ax,bx]:
        a.contour(xx,yy,d['z'],levels=np.arange(2500,7500,500),colors=['#C9D9D1'],linewidths=.55)
        a.plot(0,0,'+',color=INK,ms=7,mew=1);a.set_xlim(-4.5,4.5);a.set_ylim(-4.5,4.5)
        a.set_ylabel('相对源区南北距离（km）');a.set_yticks([-3,0,3]);a.set_xticks([-3,0,3])
    im=ax.imshow(np.ma.masked_where(d['max_depth']<.1,d['max_depth']),extent=ext,origin='upper',cmap=CR,norm=LogNorm(.1,60))
    cb=fig.colorbar(im,ax=ax,pad=.03,fraction=.055);cb.set_ticks([.1,1,10,50],labels=['0.1','1','10','50']);cb.set_label('最大层厚（m，对数色标）');panel(ax,'a  基准情景最大层厚')
    im=bx.imshow(np.ma.masked_invalid(d['arrival']),extent=ext,origin='upper',cmap=CB,vmin=0,vmax=600)
    cb=fig.colorbar(im,ax=bx,pad=.03,fraction=.055);cb.set_label('到达时刻（s）');panel(bx,'b  基准情景到达时刻')
    bx.set_xlabel('相对释放源东西距离（km）')
    save(fig,'F15_最大层厚与到达时刻','q4','基准情景最大层厚与到达时刻',
         '最大层厚按全模拟过程逐网格取最大值；到达时刻定义为层厚第一次达到0.1米。未达到该阈值的位置不赋予到达时间。',
         f'距算法释放源1千米圆周的首次越界为{s["reference_scenario"]["first_1km_crossing_s"]:.2f}秒，最大径向传播距离为{s["reference_scenario"]["max_distance_from_source_km"]:.3f}千米。1千米圆周是内部数值诊断位置，并非吉隆口岸位置或居民点，因此不能把该秒数称为实际预警提前量。')

    q=pd.read_csv(RES/'sim_scenarios.csv');grid=pd.read_csv(RES/'sim_grid_sensitivity.csv')
    timeline=pd.read_csv(RES/'sim_timeline.csv');q=q[q.xi_ms2==1000]
    pv=q.pivot(index='mu',columns='fraction',values='peak_speed_ms').sort_index()
    fig,axs=plt.subplots(3,1,figsize=(6.6,8.8))
    ax,bx,cx=axs
    im=ax.imshow(pv,aspect='auto',cmap=CR)
    ax.set_xticks(range(len(pv.columns)),[f'{f:.2f}' for f in pv.columns]);ax.set_yticks(range(len(pv.index)),[f'{f:.2f}' for f in pv.index])
    ax.set_xlabel('冰厚释放比例');ax.set_ylabel('库仑摩擦系数');panel(ax,'a  参数情景：峰值速度（m/s）')
    for i in range(pv.shape[0]):
        for j in range(pv.shape[1]):ax.text(j,i,f'{pv.iloc[i,j]:.2f}',ha='center',va='center')
    bx.plot(grid.dx_m,grid.first_1km_crossing_s,'o-',color=C[0],ms=6)
    bx.set_xticks([75,150,300]);bx.set_xlabel('网格分辨率（m）');bx.set_ylabel('1 km首次越界（s）');panel(bx,'b  网格敏感性：尚未收敛')
    bx.set_ylim(0,max(40,grid.first_1km_crossing_s.max()+10))
    for a,b in zip(grid.dx_m,grid.first_1km_crossing_s):bx.text(a,b+3,f'{b:.1f}',ha='center')
    mass0=timeline.stored_volume_m3.iloc[0]
    err=(timeline.stored_volume_m3+timeline.outflow_volume_m3-mass0)/mass0
    cx.plot(timeline.time_s,timeline.energy_ratio,'o-',color=C[2],ms=3)
    cx.set_xlabel('模拟时间（s）');cx.set_ylabel('相对初始总能量');panel(cx,'c  能量耗散与质量守恒核查')
    cx.set_ylim(.55,1.04)
    cx.text(.98,.92,f'最大相对质量误差 {np.max(np.abs(err)):.1e}',transform=cx.transAxes,ha='right',va='top')
    gr=grid.set_index('dx_m').first_1km_crossing_s
    save(fig,'F16_参数数值敏感性','q4','参数敏感性与数值可靠性联合诊断',
         '上图为释放比例与摩擦系数的交叉情景，中央为等初始体积的75、150和300米网格比较，底图为基准情景全时段相对总能量与最大相对质量误差。',
         f'库仑摩擦与释放体积共同改变峰值速度。1千米首次越界分别为75米网格{gr.loc[75]:.2f}秒、150米网格{gr.loc[150]:.2f}秒与300米网格{gr.loc[300]:.2f}秒，不能据此宣称所有指标网格收敛。总能量下降至初始值的{s["reference_scenario"]["final_energy_ratio"]:.3f}，质量误差约为机器精度；这些检查证实数值核算性质，不能替代真实事件校准。参数集合的2.5%—97.5%分位是情景包络，不是具有95%覆盖率的预报区间。')

if __name__=='__main__':
    if (RES/'figure_manifest.json').exists():
        MAN=json.loads((RES/'figure_manifest.json').read_text())
    sections=set(sys.argv[1:] or ['met','geo','sim'])
    if 'met' in sections:
        MAN=[r for r in MAN if not r['stem'].startswith(tuple(f'F{i:02}_' for i in range(1,9)))]
        plot_met()
    if 'geo' in sections:plot_geo()
    if 'sim' in sections:plot_sim()
