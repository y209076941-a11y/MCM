#!/usr/bin/env python3
"""Execute the complete local research workflow, without implicit network retries.

Run from any directory: python /path/to/MCM_study/code/run_all.py
The package contains inputs and previous results, but excludes the large vendor
directory. A clean virtual environment installed from requirements.txt suffices.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
CODE=ROOT/'code'; LOG=ROOT/'logs'; PAPER=ROOT/'manuscript'
STEPS=['met_analysis','geo_analysis','trigger_model','simulation','external_data',
       'plot_results','assemble_paper','build_paper','pdf','validate_outputs']

def run_command(command:list[str],name:str,env:dict[str,str]):
    LOG.mkdir(exist_ok=True)
    path=LOG/(name+'.log')
    print(f'[{name}] running; log: {path.relative_to(ROOT)}',flush=True)
    with path.open('w',encoding='utf-8') as f:
        proc=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    if proc.returncode:
        print(path.read_text(errors='replace')[-6000:],file=sys.stderr)
        raise RuntimeError(f'{name} failed with exit code {proc.returncode}; see {path}')
    print(f'[{name}] completed',flush=True)

def convert_pdf(soffice:str,env:dict[str,str],pass_number:int):
    doc=PAPER/'吉隆灾害链建模论文.docx'
    if not doc.exists():raise FileNotFoundError(doc)
    # A new output directory avoids stale PDF overwrite/LibreOffice lock issues.
    with tempfile.TemporaryDirectory(prefix='mcm-pdf-') as tmp:
        tmp=Path(tmp);profile=tmp/'profile';out=tmp/'converted';out.mkdir()
        run_command([soffice,'-env:UserInstallation='+profile.as_uri(),'--headless',
                     '--convert-to','pdf:writer_pdf_Export:{"ReduceImageResolution":{"type":"boolean","value":"false"}}',
                     '--outdir',str(out),str(doc)],
                    f'pdf_pass{pass_number}',env)
        pdf=out/(doc.stem+'.pdf')
        if not pdf.exists() or pdf.stat().st_size<1000:
            raise RuntimeError('LibreOffice returned without a usable PDF; inspect its log')
        shutil.copy2(pdf,PAPER/pdf.name)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--start-from',choices=STEPS,default='met_analysis',
                    help='Resume a stage; existing prerequisite outputs are required')
    ap.add_argument('--skip-paper',action='store_true',help='Compute and plot only')
    ap.add_argument('--skip-pdf',action='store_true',help='Generate DOCX without PDF conversion')
    ap.add_argument('--retry-external',action='store_true',
                    help='Explicitly retry public API calls after network settings change')
    ap.add_argument('--soffice',default=shutil.which('soffice') or shutil.which('libreoffice'),
                    help='Path to LibreOffice executable, required for PDF')
    args=ap.parse_args()
    env=os.environ.copy()
    env.setdefault('OPENBLAS_NUM_THREADS','2');env.setdefault('OMP_NUM_THREADS','2')
    env.setdefault('MPLCONFIGDIR',str(ROOT/'figures/.mplconfig'))
    # Do not distribute vendor. In the prepared cloud environment, use its stack
    # consistently, including the meteorology script that has no sys.path edits.
    if (ROOT/'vendor').is_dir():
        env['PYTHONPATH']=str(ROOT/'vendor')+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
    status=[]
    for step in STEPS[STEPS.index(args.start_from):]:
        if args.skip_paper and step in ['assemble_paper','build_paper','pdf']:
            status.append(dict(step=step,status='skipped_by_request'));continue
        if args.skip_pdf and step=='pdf':
            status.append(dict(step=step,status='skipped_by_request'));continue
        if step=='pdf':
            if not args.soffice:
                raise RuntimeError('PDF conversion needs LibreOffice/soffice. Install it or use --skip-pdf; no PDF was produced.')
            convert_pdf(args.soffice,env,1)
            # The second pass reads actual rendered heading pages into the TOC.
            run_command([sys.executable,str(CODE/'build_paper.py'),'--toc-from',
                         str(PAPER/'吉隆灾害链建模论文.pdf')],'build_paper_toc',env)
            convert_pdf(args.soffice,env,2)
        else:
            script=CODE/(step+'.py')
            if not script.exists():
                if step=='assemble_paper' and (PAPER/'paper_blocks.json').exists():
                    status.append(dict(step=step,status='existing_paper_blocks_used'));continue
                raise FileNotFoundError(f'Required stage is absent: {script}')
            command=[sys.executable,str(script)]
            if step=='external_data' and args.retry_external:command.append('--retry')
            if step=='validate_outputs':
                if args.skip_paper:command.append('--allow-incomplete-paper')
                elif args.skip_pdf:command.append('--allow-missing-pdf')
            run_command(command,step,env)
        status.append(dict(step=step,status='completed'))
    (ROOT/'results/run_status.json').write_text(json.dumps(dict(
        finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        python=sys.version,steps=status),ensure_ascii=False,indent=2),encoding='utf-8')
    print('Workflow completed. See manuscript/, figures/, results/ and logs/.')

if __name__=='__main__':main()
