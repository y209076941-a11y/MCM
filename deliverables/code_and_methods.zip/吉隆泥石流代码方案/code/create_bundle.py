"""Package complete auditable deliverables, excluding installed libraries/cache."""
from pathlib import Path
import json,zipfile,hashlib,shutil

ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT.parent/'shared/downloads'

def members():
    files=[]
    for top in ['code','data','results','figures','manuscript']:
        for p in sorted((ROOT/top).rglob('*')):
            rel=p.relative_to(ROOT)
            if not p.is_file():continue
            if any(x in rel.parts for x in ['__pycache__','.mplconfig','preview']):continue
            if p.suffix in ['.pyc'] or p.name.endswith('_paper.png'):continue
            files.append(p)
    for name in ['README_运行说明.md','requirements.txt','交付说明.md']:
        p=ROOT/name
        if p.exists():files.append(p)
    return files

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def main():
    DEST.mkdir(parents=True,exist_ok=True)
    files=[p for p in members() if p.name!='deliverable_checksums.json']
    manifest=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=digest(p)) for p in files]
    mf=ROOT/'results/deliverable_checksums.json';mf.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    full=DEST/'吉隆泥石流_完整代码方案与论文.zip'
    with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[mf]:z.write(p,'吉隆泥石流研究/'+str(p.relative_to(ROOT)))
    light=DEST/'吉隆泥石流_代码与建模方案.zip'
    keep=[p for p in files if p.relative_to(ROOT).parts[0]=='code' or p.name in ['README_运行说明.md','requirements.txt','交付说明.md','完整建模方案与论文源稿.md','methods_blocks.json','paper_blocks.json','parameter_index.json','figure_manifest.json','ext_summary.json','ext_bibliography.json','review_findings.md']]
    with zipfile.ZipFile(light,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in keep:z.write(p,'吉隆泥石流代码方案/'+str(p.relative_to(ROOT)))
    for suffix in ['docx','pdf']:
        p=ROOT/'manuscript'/('吉隆灾害链建模论文.'+suffix);shutil.copy2(p,DEST/p.name)
    # CRC is independent of SHA record; verify every archived member is readable.
    for p in [full,light]:
        with zipfile.ZipFile(p) as z:
            bad=z.testzip()
            if bad:raise RuntimeError('Corrupt zip member '+bad)
        print(p,round(p.stat().st_size/1024**2,2),'MiB',digest(p))

if __name__=='__main__':main()
