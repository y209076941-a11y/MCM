#!/usr/bin/env python3
"""Q4: conservative scenario simulation on supplied DEM, NOT event reconstruction.
References: Friction-balanced shallow-layer predictor-corrector with conservative upwind momentum transport;
Voellmy (1955), Schweizerische Bauzeitung 73:159-162, 212-217, 246-249, 280-285.
All releases and rheology choices are scenarios, not fitted event parameters.
"""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
import numpy as np,pandas as pd,xarray as xr,rasterio
from rasterio.warp import reproject,Resampling,transform_bounds
from rasterio.transform import from_origin
G=9.81;H_DRY=1e-5
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)

def surface_gradient(h,z,dx):
 """Centered free-surface gradient with dry higher-bed wall treatment."""
 eta=h+z;E=np.pad(eta,1,mode='edge');H=np.pad(h,1,mode='edge');Z=np.pad(z,1,mode='edge')
 l=E[1:-1,:-2].copy();r=E[1:-1,2:].copy();t=E[:-2,1:-1].copy();b=E[2:,1:-1].copy()
 l=np.where((H[1:-1,:-2]<=H_DRY)&(Z[1:-1,:-2]>eta),eta,l)
 r=np.where((H[1:-1,2:]<=H_DRY)&(Z[1:-1,2:]>eta),eta,r)
 t=np.where((H[:-2,1:-1]<=H_DRY)&(Z[:-2,1:-1]>eta),eta,t)
 b=np.where((H[2:,1:-1]<=H_DRY)&(Z[2:,1:-1]>eta),eta,b)
 return (r-l)/(2*dx),(b-t)/(2*dx)

def friction(qx,qy,h,dt,mu,xi,cost):
 mag=np.hypot(qx,qy)
 factor=np.divide(np.maximum(mag-dt*mu*G*h*cost,0),mag,out=np.zeros_like(h),where=mag>0)
 qx=qx*factor;qy=qy*factor;mag=np.hypot(qx,qy)
 den=1+dt*G*np.divide(mag,xi*h*h,out=np.zeros_like(h),where=h>H_DRY)
 return qx/den,qy/den

def full_step(U,z,dx,dt,mu,xi,bc='open'):
 """Friction-balanced pressure predictor + conservative upwind momentum transport.
 Full nonlinear advective momentum retained; no artificial mass-diffusion flux.
 """
 h=U[0];eta=h+z;u=np.divide(U[1],h,out=np.zeros_like(h),where=h>H_DRY);v=np.divide(U[2],h,out=np.zeros_like(h),where=h>H_DRY)
 gx,gy=surface_gradient(h,z,dx);by,bx=np.gradient(z,dx);cost=1/np.sqrt(1+bx*bx+by*by)
 n,m=h.shape;ax=np.zeros((n,m+1));ay=np.zeros((n+1,m))
 hf=np.maximum(0,np.maximum(eta[:,:-1],eta[:,1:])-np.maximum(z[:,:-1],z[:,1:]))
 px=hf*(u[:,:-1]+u[:,1:])/2-dt/2*G*hf*(eta[:,1:]-eta[:,:-1])/dx
 py=hf*(v[:,:-1]+v[:,1:])/2-dt/2*G*hf*(gy[:,:-1]+gy[:,1:])/2
 px,py=friction(px,py,hf,dt/2,mu,xi,(cost[:,:-1]+cost[:,1:])/2)
 ax[:,1:-1]=px
 hf=np.maximum(0,np.maximum(eta[:-1,:],eta[1:,:])-np.maximum(z[:-1,:],z[1:,:]))
 px=hf*(u[:-1,:]+u[1:,:])/2-dt/2*G*hf*(gx[:-1,:]+gx[1:,:])/2
 py=hf*(v[:-1,:]+v[1:,:])/2-dt/2*G*hf*(eta[1:,:]-eta[:-1,:])/dx
 px,py=friction(px,py,hf,dt/2,mu,xi,(cost[:-1,:]+cost[1:,:])/2)
 ay[1:-1,:]=py
 if bc=='open':
  ax[:,0]=np.minimum(U[1,:,0],0);ax[:,-1]=np.maximum(U[1,:,-1],0)
  ay[0,:]=np.minimum(U[2,0,:],0);ay[-1,:]=np.maximum(U[2,-1,:],0)
 outgoing=np.maximum(ax[:,1:],0)+np.maximum(-ax[:,:-1],0)+np.maximum(ay[1:,:],0)+np.maximum(-ay[:-1,:],0)
 factor=np.minimum(1,np.divide(h*dx,dt*outgoing,out=np.ones_like(h),where=dt*outgoing>0))
 lf=np.pad(factor,((0,0),(1,0)),constant_values=1);rf=np.pad(factor,((0,0),(0,1)),constant_values=1)
 uf=np.pad(factor,((1,0),(0,0)),constant_values=1);df=np.pad(factor,((0,1),(0,0)),constant_values=1)
 ax*=np.where(ax>=0,lf,rf);ay*=np.where(ay>=0,uf,df)
 hn=h-dt/dx*(ax[:,1:]-ax[:,:-1]+ay[1:,:]-ay[:-1,:]);negative=float(hn.min())
 if negative < -1e-8:raise RuntimeError(f'negative depth {negative}')
 hn=np.maximum(hn,0)
 # Momentum advected by the exact same donor-limited physical mass flux.
 ul=np.pad(u,((0,0),(1,0)),mode='edge');ur=np.pad(u,((0,0),(0,1)),mode='edge')
 vl=np.pad(v,((0,0),(1,0)),mode='edge');vr=np.pad(v,((0,0),(0,1)),mode='edge')
 ut=np.pad(u,((1,0),(0,0)),mode='edge');ub=np.pad(u,((0,1),(0,0)),mode='edge')
 vt=np.pad(v,((1,0),(0,0)),mode='edge');vb=np.pad(v,((0,1),(0,0)),mode='edge')
 fxu=ax*np.where(ax>=0,ul,ur);fxv=ax*np.where(ax>=0,vl,vr)
 fyu=ay*np.where(ay>=0,ut,ub);fyv=ay*np.where(ay>=0,vt,vb)
 qxn=U[1]-dt/dx*(fxu[:,1:]-fxu[:,:-1]+fyu[1:,:]-fyu[:-1,:])-dt*G*hn*gx
 qyn=U[2]-dt/dx*(fxv[:,1:]-fxv[:,:-1]+fyv[1:,:]-fyv[:-1,:])-dt*G*hn*gy
 qxn,qyn=friction(qxn,qyn,hn,dt,mu,xi,cost)
 qxn[hn<=H_DRY]=0;qyn[hn<=H_DRY]=0
 out=dt*dx*(ax[:,-1].sum()-ax[:,0].sum()+ay[-1,:].sum()-ay[0,:].sum())
 return np.stack([hn,qxn,qyn]),out,negative

def energy(U,z,dx):
 h=U[0];kin=.5*np.divide(U[1]*U[1]+U[2]*U[2],h,out=np.zeros_like(h),where=h>H_DRY)
 return float((kin+.5*G*h*h+G*h*(z-z.min())).sum()*dx*dx)

def numerical_tests():
 n=25;dx=10.;yy,xx=np.mgrid[:n,:n];z=.5*np.exp(-((xx-12)**2+(yy-12)**2)/20)
 U=np.zeros((3,n,n));U[0]=2-z;initial=U.copy()
 for _ in range(100):U,_,_=full_step(U,z,dx,.1,0,1000,'reflect')
 lake_depth=float(np.max(np.abs(U[0]-initial[0])));lake_q=float(abs(U[1:]).max())
 z=np.zeros((n,n));U.fill(0);U[0,9:16,9:16]=1;v0=U[0].sum()*dx*dx
 dam_energy=[energy(U,z,dx)]
 for _ in range(100):
  U,_,_=full_step(U,z,dx,.1,0,1000,'reflect');dam_energy.append(energy(U,z,dx))
 mass=abs(U[0].sum()*dx*dx-v0)/v0;dam_min=float(U[0].min())
 z=np.zeros((n,n));U.fill(0);U[0]=np.exp(-((xx-12)**2+(yy-12)**2)/20);pile=U.copy()
 for _ in range(100):U,_,_=full_step(U,z,dx,.1,.08,1000,'reflect')
 drift=float(abs(U[0]-pile[0]).max());qstatic=float(abs(U[1:]).max())
 assert lake_depth<1e-12 and lake_q<1e-10 and mass<1e-12 and dam_min>=0 and drift==0 and qstatic==0 and max(dam_energy)<=dam_energy[0]*(1+1e-10)
 return {'lake_at_rest_max_depth_error_m':lake_depth,'lake_at_rest_max_momentum_error_m2_s':lake_q,'closed_flat_dambreak_relative_volume_error':float(mass),'closed_flat_dambreak_min_depth_m':dam_min,'static_friction_pile_max_depth_drift_m':drift,'static_friction_pile_max_momentum_m2_s':qstatic,'steps_each':100,'static_pile_mu':.08,'closed_flat_dambreak_initial_energy_m5s2':dam_energy[0],'closed_flat_dambreak_final_energy_m5s2':dam_energy[-1],'closed_flat_dambreak_max_energy_increase_fraction':(max(dam_energy)-dam_energy[0])/dam_energy[0]}

def prepare_grid(dx=150.):
 f=next((ROOT/'data/dataset_4').glob('*.nc'));d=xr.open_dataset(f)
 valid=(d.glacier_mask.values==1)&(d.dem.values>=5000)&(d.slope.values>=25)&np.isfinite(d.thickness.values)
 score=np.where(valid,d.thickness.values*np.sin(np.deg2rad(d.slope.values)),-np.inf)
 si,sj=np.unravel_index(np.argmax(score),score.shape);sx=float(d.x[sj]);sy=float(d.y[si])
 with rasterio.open(ROOT/'data/dataset_7/DEM.tif') as ds:
  bounds=transform_bounds(ds.crs,'EPSG:32645',*ds.bounds,densify_pts=21)
  xmin=max(bounds[0]+1000,sx-6000);xmax=min(bounds[2]-1000,sx+6000)
  ymin=max(bounds[1]+1000,sy-5000);ymax=min(bounds[3]-1000,sy+6500)
  nx=int((xmax-xmin)/dx);ny=int((ymax-ymin)/dx);tr=from_origin(xmin,ymax,dx,dx)
  z=np.full((ny,nx),np.nan,dtype='float32')
  reproject(rasterio.band(ds,1),z,src_transform=ds.transform,src_crs=ds.crs,dst_transform=tr,dst_crs='EPSG:32645',resampling=Resampling.average,dst_nodata=np.nan)
 assert np.isfinite(z).all()
 x=xmin+(np.arange(nx)+.5)*dx;y=ymax-(np.arange(ny)+.5)*dx;X,Y=np.meshgrid(x,y)
 from rasterio.transform import Affine
 src_tr=Affine.from_gdal(*map(float,d.spatial_ref.attrs['GeoTransform'].split()))
 thick=np.zeros_like(z)
 source=np.nan_to_num(d.thickness.values,nan=0)*np.nan_to_num(d.glacier_mask.values,nan=0)
 reproject(source,thick,src_transform=src_tr,src_crs='EPSG:32645',dst_transform=tr,dst_crs='EPSG:32645',resampling=Resampling.average)
 # Mapped glacier patch within 450m; release fraction of mapped ice thickness.
 mask=(X-sx)**2+(Y-sy)**2<=450**2
 rel=thick*mask
 assert rel.sum()>0
 meta={'dx_m':dx,'shape':[ny,nx],'source_utm45n_m':[sx,sy],'source_geographic_elevation_m':float(d.dem.values[si,sj]),'source_nc_slope_deg':float(d.slope.values[si,sj]),'source_nc_thickness_m':float(d.thickness.values[si,sj]),'source_rule':'argmax(thickness sin(slope)) among mapped glacier cells with elevation>=5000m and slope>=25deg; release mapped thickness within450m','source_radius_m':450,'source_bulk_interpretation':'release fraction times mapped ice thickness is prescribed equivalent bulk-layer depth; ice-to-debris conversion is not modeled','mapped_patch_full_ice_volume_m3':float(rel.astype(float).sum()*dx*dx),'projection':'EPSG:32645','duration_s':600,'model':'2D full shallow-layer momentum: friction-balanced vector face predictor, conservative donor-limited mass and upwind momentum advection, free-surface pressure-gradient corrector and isotropic Voellmy friction','entrainment':False,'boundary':'open; flux accounted; runout censored if boundary outflow','CFL':.20,'dry_depth_m':H_DRY,'rho_mixture_kg_m3':1800,'rho_usage':'only momentum/pressure interpretation; density cancels governing mass-momentum for homogeneous mixture','scenario_not_calibrated':True}
 return z.astype(float),x,y,rel.astype(float),meta

def simulate(z,x,y,release,meta,fraction,mu,xi,save=False):
 dx=meta['dx_m'];sx,sy=meta['source_utm45n_m'];X,Y=np.meshgrid(x,y)
 U=np.zeros((3,*z.shape));U[0]=fraction*release
 v0=float(U[0].sum()*dx*dx);e0=energy(U,z,dx);maxenergy=e0;outvol=0.;t=0.;steps=0;maxdepth=U[0].copy();maxspeed=np.zeros_like(z);maxfr=np.zeros_like(z)
 arrival=np.full_like(z,np.nan);arrival[U[0]>=.1]=0
 distance=np.hypot(X-sx,Y-sy);receptor=distance>=1000
 receptor_arrival=None;timeline=[{'time_s':0.,'stored_volume_m3':v0,'outflow_volume_m3':0.,'max_depth_m':float(U[0].max()),'energy_m5s2':e0,'energy_ratio':1.,'max_speed_ms':0.,'max_froude':0.,'supercritical_wet_fraction':0.,'instant_area_km2':float((U[0]>=.1).sum()*dx*dx/1e6),'front_distance_km':float(distance[U[0]>=.1].max()/1000)}];snaps=[U[0].astype('float32').copy()] if save else [];nextsnap=30;negative=0.
 while t<600-1e-10:
  h=U[0];uc=np.divide(U[1],h,out=np.zeros_like(h),where=h>H_DRY);vc=np.divide(U[2],h,out=np.zeros_like(h),where=h>H_DRY)
  dt=min(.20*dx/max(float((2*np.sqrt(G*h)+abs(uc)+abs(vc)).max()),1e-9),1.,600-t)
  U,out,ng=full_step(U,z,dx,dt,mu,xi);t+=dt;steps+=1;outvol+=out;negative=min(negative,ng);h=U[0]
  maxdepth=np.maximum(maxdepth,h);et=energy(U,z,dx);maxenergy=max(maxenergy,et)
  uc=np.divide(U[1],h,out=np.zeros_like(h),where=h>.1);vc=np.divide(U[2],h,out=np.zeros_like(h),where=h>.1)
  speed=np.hypot(uc,vc);maxspeed=np.maximum(maxspeed,speed)
  fr=np.divide(speed,np.sqrt(G*h),out=np.zeros_like(h),where=h>.1);maxfr=np.maximum(maxfr,fr)
  wet=h>=.1;arrival[wet&np.isnan(arrival)]=t
  if receptor_arrival is None and np.any(wet&receptor):receptor_arrival=t
  if t>=nextsnap or t>=600-1e-10:
   timeline.append({'time_s':t,'stored_volume_m3':float(h.sum()*dx*dx),'outflow_volume_m3':float(outvol),'max_depth_m':float(h.max()),'energy_m5s2':et,'energy_ratio':et/e0,'max_speed_ms':float(speed.max()),'max_froude':float(fr.max()),'supercritical_wet_fraction':float((wet&(fr>1)).sum()/max(wet.sum(),1)),'instant_area_km2':float(wet.sum()*dx*dx/1e6),'front_distance_km':float(distance[wet].max()/1000) if wet.any() else 0})
   if save:snaps.append(h.astype('float32').copy())
   nextsnap+=30
 footprint=maxdepth>=.1;remaining=float(h.sum()*dx*dx);error=(remaining+outvol-v0)/v0
 assert abs(error)<1e-8,(error,v0,remaining,outvol)
 result={'fraction':float(fraction),'mu':mu,'xi_ms2':xi,'initial_volume_m3':v0,'remaining_volume_m3':remaining,'boundary_outflow_m3':float(outvol),'outflow_fraction':float(outvol/v0),'relative_mass_error':float(error),'steps':steps,'minimum_depth_roundoff_m':negative,'max_depth_m':float(maxdepth.max()),'peak_speed_ms':float(maxspeed.max()),'max_energy_increase_fraction':(maxenergy-e0)/e0,'final_energy_ratio':et/e0,'max_froude':float(maxfr.max()),'ever_supercritical_footprint_fraction':float(((maxfr>1)&footprint).sum()/max(footprint.sum(),1)),'footprint_km2':float(footprint.sum()*dx*dx/1e6),'max_distance_from_source_km':float(distance[footprint].max()/1000),'first_1km_crossing_s':receptor_arrival,'boundary_censored':bool(outvol/v0>.001)}
 if save:
  np.savez_compressed(OUT/'sim_fields.npz',x=x,y=y,z=z,max_depth=maxdepth,max_speed=maxspeed,max_froude=maxfr,arrival=arrival,snapshots=np.stack(snaps),snapshot_times=np.array([r['time_s'] for r in timeline]),release_depth=fraction*release,source_xy=np.array([sx,sy]),cellsize=dx,final_momentum=U[1:])
  pd.DataFrame(timeline).to_csv(OUT/'sim_timeline.csv',index=False)
 return result,maxdepth,arrival

def main():
 start=time.time();tests=numerical_tests();z,x,y,release,meta=prepare_grid();runs=[];depths=[];arrivals=[]
 scenarios=[(f,mu,1000.) for f in [.1,.2,.3] for mu in [.08,.15,.22]]+[(.2,.15,500.),(.2,.15,1500.)]
 for k,(f,mu,xi) in enumerate(scenarios):
  r,dep,arr=simulate(z,x,y,release,meta,f,mu,xi,save=(f==.2 and mu==.15 and xi==1000))
  r['scenario_id']=k+1;runs.append(r);depths.append(dep);arrivals.append(arr)
  print(json.dumps(r),flush=True)
 frame=pd.DataFrame(runs);frame.to_csv(OUT/'sim_scenarios.csv',index=False)
 depth_stack=np.stack(depths);arrival_stack=np.stack(arrivals)
 np.savez_compressed(OUT/'sim_ensemble.npz',scenario_max_depth=depth_stack,scenario_arrival=arrival_stack,inundation_frequency=(depth_stack>=.1).mean(axis=0),maxdepth_q025=np.quantile(depth_stack,.025,axis=0),maxdepth_q975=np.quantile(depth_stack,.975,axis=0),x=x,y=y)
 summary={'meta':meta,'numerical_verification':tests,'reference_scenario':runs[4],'scenario_parameter_grid':{'fraction':[.1,.2,.3],'mu':[.08,.15,.22],'xi':[500,1000,1500],'base_xi':1000,'design':'9 crossed volume-fraction/Coulomb cases plus2 xi sensitivity cases; equal-weight scenarios not statistical posterior'},'scenario_envelope':{},'arrival_censoring':{'diagnostic_radius_m':1000,'observation_end_s':600,'n_scenarios':len(runs),'n_reached_by_end':int(frame['first_1km_crossing_s'].notna().sum()),'n_not_reached_right_censored':int(frame['first_1km_crossing_s'].isna().sum()),'arrival_quantile_scope':'conditional on scenarios reaching1km by600s; excludes right-censored cases; not a forecastconfidenceinterval'},'limitations':['scenario source is algorithmic, not independently identified collapse scar','source glacier velocity2014-2024 climatology cannot determine2026 acceleration','no entrainment, pore-pressure, grain segregation, ice melting, blockage/dam breach or building effects','150m average DEM smooths channels and cannot support site-scale engineering','full momentum advection retained; steep-cliff hydrostatic shallow-layer and constant-rheology assumptions still limit physical interpretation; no event calibration' ,'95% ensemble quantiles reflect selected parameter design only, not calibrated predictive coverage','radius1km crossing is a generic internal diagnostic, not port impact or alarm lead time'],'runtime_s':time.time()-start}
 for col in ['initial_volume_m3','max_distance_from_source_km','first_1km_crossing_s','peak_speed_ms','footprint_km2','outflow_fraction','max_froude']:
  a=frame[col].dropna().to_numpy();summary['scenario_envelope'][col]={'min':float(a.min()),'max':float(a.max()),'q025':float(np.quantile(a,.025)),'q975':float(np.quantile(a,.975))}
 grid_rows=[];target=runs[4]['initial_volume_m3']
 for resolution in [75.,150.,300.]:
  zg,xg,yg,rg,mg=prepare_grid(resolution)
  equal_volume_fraction=target/(rg.sum()*resolution*resolution)
  rr,_,_=simulate(zg,xg,yg,rg,mg,equal_volume_fraction,.15,1000.,save=False)
  rr['dx_m']=resolution;grid_rows.append(rr)
 pd.DataFrame(grid_rows).to_csv(OUT/'sim_grid_sensitivity.csv',index=False)
 summary['grid_sensitivity']=grid_rows
 summary['runtime_s']=time.time()-start
 summary['limitations'].append('75/150/300m equal-volume grid sensitivity must be consulted; no grid-converged engineering arrival or runout claim')
 (OUT/'sim_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 print('FINISHED',summary['runtime_s'],flush=True)
if __name__=='__main__':main()
