"""Geospatial audit and positive-unlabeled spatial assessment; no event labels invented.
Run: PYTHONPATH=/workspace/MCM_study/vendor python code/geo_analysis.py
"""
from pathlib import Path
import sys,json,heapq,warnings
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
import numpy as np,pandas as pd,rasterio,geopandas as gpd,xarray as xr
from rasterio.warp import reproject,calculate_default_transform,Resampling
from rasterio.features import rasterize
from scipy.ndimage import distance_transform_edt,uniform_filter
from scipy.spatial import cKDTree
from sklearn.pipeline import make_pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler,OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import roc_auc_score,average_precision_score,roc_curve,precision_recall_curve
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'data';OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
RNG=np.random.default_rng(20261023)

def clean(v):
 if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [clean(x) for x in v]
 if isinstance(v,np.ndarray):return clean(v.tolist())
 if isinstance(v,np.generic):return v.item()
 if isinstance(v,Path):return str(v)
 return v

def quant(a):
 a=np.asarray(a);a=a[np.isfinite(a)]
 return dict(zip(['min','p05','q25','median','q75','p95','max'],np.quantile(a,[0,.05,.25,.5,.75,.95,1]).tolist()))

def priority_flood(z,mask):
 """Priority flood, boundary seeded; epsilon breaks flats only (not measured elevation)."""
 h,w=z.shape;fill=z.astype(np.float64).copy();seen=~mask.copy();heap=[]
 for y,x in zip(*np.where(mask)):
  if y in (0,h-1) or x in (0,w-1) or not mask[max(0,y-1):min(h,y+2),max(0,x-1):min(w,x+2)].all():
   seen[y,x]=True;heapq.heappush(heap,(float(fill[y,x]),int(y),int(x)))
 while heap:
  elev,y,x=heapq.heappop(heap)
  for dy,dx in [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]:
   yy,xx=y+dy,x+dx
   if 0<=yy<h and 0<=xx<w and not seen[yy,xx]:
    seen[yy,xx]=True;fill[yy,xx]=max(z[yy,xx],elev+1e-5)
    heapq.heappush(heap,(float(fill[yy,xx]),yy,xx))
 return fill

def flow_accum(fill,mask,cell):
 h,w=fill.shape;down=np.full(fill.size,-1,np.int64);acc=np.where(mask,1.,0.).ravel()
 for y,x in zip(*np.where(mask)):
  best=0.;dest=-1
  for dy,dx in [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]:
   yy,xx=y+dy,x+dx
   if 0<=yy<h and 0<=xx<w and mask[yy,xx]:
    slope=(fill[y,x]-fill[yy,xx])/(cell*np.hypot(dy,dx))
    if slope>best:best=slope;dest=yy*w+xx
  down[y*w+x]=dest
 for i in np.argsort(np.where(mask,fill,-np.inf).ravel())[::-1]:
  if down[i]>=0:acc[down[i]]+=acc[i]
 return acc.reshape(fill.shape),down.reshape(fill.shape)

summary={'seed':20261023,'scope':'retrospective spatial inventory membership, NOT calibrated debris-flow occurrence probability','crs':'EPSG:32645','resolution_m':200}
# Original raster metadata
with rasterio.open(D/'dataset_7/DEM.tif') as src:
 summary['dem']={'shape':src.shape,'crs':str(src.crs),'bounds':list(src.bounds),'resolution_degrees':src.res,'nodata':src.nodata,'provenance_caveat':'File named for 2026-08-26; survey/acquisition epoch is not supplied. Do not claim pre-event hindcast terrain.'}
 trans,w,h=calculate_default_transform(src.crs,'EPSG:32645',src.width,src.height,*src.bounds,resolution=200)
 z=np.full((h,w),np.nan,np.float32)
 reproject(rasterio.band(src,1),z,src_transform=src.transform,src_crs=src.crs,dst_transform=trans,dst_crs='EPSG:32645',src_nodata=src.nodata,dst_nodata=np.nan,resampling=Resampling.bilinear)
mask=np.isfinite(z);cell=200.;xx=trans.c+(np.arange(w)+.5)*cell;yy=trans.f-(np.arange(h)+.5)*cell
nearest=distance_transform_edt(~mask,return_distances=False,return_indices=True);zn=z[tuple(nearest)]
gy,gx=np.gradient(zn,cell);slope=np.degrees(np.arctan(np.hypot(gx,gy)));aspect=np.arctan2(-gx,gy)
fill=priority_flood(zn,mask);acc,down=flow_accum(fill,mask,cell)
# Conservation check: sum of contributing cells at all outlets equals valid cells.
outlets=mask & (down<0)
assert abs(float(acc[outlets].sum())-float(mask.sum()))<1e-8
twi=np.log(np.maximum(acc*cell,cell)/np.maximum(np.tan(np.radians(slope)),.001))
curv=np.gradient(gx,cell,axis=1)+np.gradient(gy,cell,axis=0)
relief=zn-uniform_filter(zn,size=11,mode='nearest')
land={}
for year in range(2020,2024):
 with rasterio.open(D/f'dataset_5/jilong_LUCD_{year}.tif') as src:
  out=np.zeros(z.shape,np.uint8)
  reproject(rasterio.band(src,1),out,src_transform=src.transform,src_crs=src.crs,dst_transform=trans,dst_crs='EPSG:32645',dst_nodata=0,resampling=Resampling.nearest)
  land[year]=out
valid=mask&(land[2023]>0)
summary['grid']={'height':h,'width':w,'dem_valid_cells':int(mask.sum()),'joint_landcover_valid_cells':int(valid.sum()),'dem_area_km2':float(mask.sum()*cell**2/1e6),'landcover_overlap_area_km2':float(valid.sum()*cell**2/1e6),'elevation_m':quant(z[mask]),'slope_degree':quant(slope[mask]),'twi':quant(twi[mask]),'fill_depth_m':quant((fill-zn)[mask]),'total_fill_m3':float(np.sum((fill-zn)[mask])*cell**2)}
# Resolution sensitivity: uncalibrated mechanical scenario, not model performance.
scale_rows=[]
for scale in [100,200,400]:
 with rasterio.open(D/'dataset_7/DEM.tif') as src:
  ts,ws,hs=calculate_default_transform(src.crs,'EPSG:32645',src.width,src.height,*src.bounds,resolution=scale)
  zs=np.full((hs,ws),np.nan,np.float32)
  reproject(rasterio.band(src,1),zs,src_transform=src.transform,src_crs=src.crs,dst_transform=ts,dst_crs='EPSG:32645',src_nodata=src.nodata,dst_nodata=np.nan,resampling=Resampling.bilinear)
 ms=np.isfinite(zs);nn=distance_transform_edt(~ms,return_distances=False,return_indices=True);zz=zs[tuple(nn)]
 dys,dxs=np.gradient(zz,scale);ths=np.arctan(np.hypot(dxs,dys))
 for sat in [.35,1.]:
  fss=(2000+(1800-1000*sat)*9.81*1.5*np.cos(ths)**2*np.tan(np.radians(32)))/(1800*9.81*1.5*np.sin(ths)*np.cos(ths)+1e-12)
  scale_rows.append({'resolution_m':scale,'saturation_ratio':sat,'slope_median_deg':float(np.median(np.degrees(ths[ms]))),'slope_p95_deg':float(np.quantile(np.degrees(ths[ms]),.95)),'unstable_fraction':float(np.mean(fss[ms]<=1)),'valid_area_km2':float(ms.sum()*scale**2/1e6)})
pd.DataFrame(scale_rows).to_csv(OUT/'geo_scale_sensitivity.csv',index=False)
summary['resolution_sensitivity']=scale_rows
# Labels are basin polygons, NOT dated events
inv=gpd.read_file(next((D/'dataset_6').glob('*.shp')),encoding='gb18030').to_crs(32645)
census=gpd.read_file(next((D/'dataset_8').glob('*.shp'))).to_crs(32645)
shapes=[(geom,i+1) for i,geom in enumerate(inv.geometry)]
labels=rasterize(shapes,out_shape=z.shape,transform=trans,fill=0,dtype='int16')
basin_ids=np.unique(labels[mask]);basin_ids=basin_ids[basin_ids>0]
summary['inventory']={'count':len(inv),'geometry':'basin polygons','count_intersect_grid':len(basin_ids),'type_counts':inv['类型'].value_counts().to_dict(),'frequency_categories':inv['频率'].value_counts().to_dict(),'interpretation_dates':inv['解译Time'].astype(str).value_counts().to_dict(),'imagery_dates':inv['影像Time'].astype(str).value_counts().to_dict(),'event_times_available':False,'warning':'Image and interpretation dates cannot serve as disaster occurrence times; polygons delimit susceptible catchments, not observed inundation.'}
# CSV for plotting actual inventory boundaries in projected coordinates
boundaries=[]
for i,row in inv.iterrows():
 geom=row.geometry
 for ring in ([geom.exterior] if geom.geom_type=='Polygon' else [p.exterior for p in geom.geoms]):
  for coord in ring.coords:boundaries.append((i+1,row['Code'],coord[0],coord[1]))
pd.DataFrame(boundaries,columns=['basin_id','code','x','y']).to_csv(OUT/'geo_boundaries.csv',index=False)
attrs=inv.drop(columns='geometry').copy();attrs['basin_id']=np.arange(1,len(inv)+1);attrs['area_geom_km2']=inv.area/1e6;attrs.to_csv(OUT/'geo_inventory.csv',index=False)
# Numeric land cover without unverifiable category interpretation
areas=[];transitions=[]
for year in range(2020,2024):
 with rasterio.open(D/f'dataset_5/jilong_LUCD_{year}.tif') as src:
  a=src.read(1);lat_top=src.transform.f+np.arange(src.height)*src.transform.e;lat_bottom=lat_top+src.transform.e
  # Authalic-sphere pixel area, reproducible <0.5% approximation to ellipsoid
  rowarea=6371007.1809**2*np.radians(abs(src.transform.a))*np.abs(np.sin(np.radians(lat_top))-np.sin(np.radians(lat_bottom)))
  for c in range(1,11):areas.append({'year':year,'class_code':c,'cells':int((a==c).sum()),'area_km2':float(np.sum((a==c)*rowarea[:,None])/1e6)})
  if year==2020:a0=a
  if year==2023:
   for c1 in range(1,11):
    for c2 in range(1,11):transitions.append({'from_code':c1,'to_code':c2,'cells':int(((a0==c1)&(a==c2)).sum()),'area_km2':float(np.sum(((a0==c1)&(a==c2))*rowarea[:,None])/1e6)})
pd.DataFrame(areas).to_csv(OUT/'geo_landcover_area.csv',index=False);pd.DataFrame(transitions).to_csv(OUT/'geo_landcover_transition.csv',index=False)
summary['landcover']={'legend_supplied':False,'class_codes':list(range(1,11)),'area_method':'authalic-sphere pixel areas with row latitude','changed_2020_2023_km2':float(sum(r['area_km2'] for r in transitions if r['from_code']!=r['to_code'])),'total_2023_km2':float(sum(r['area_km2'] for r in areas if r['year']==2023)),'common_valid_2020_2023_km2':float(sum(r['area_km2'] for r in transitions)),'coverage_caveat':'Transitions count only pixels with nonzero class in both years; valid footprint differs slightly among years. Coverage change is not labeled landcover conversion.'}
# County population attributes are aggregates, no small-area allocation inferred
cp=census.iloc[0]
summary['population']={'county':str(cp['地名']),'total_population_field':int(cp['合计']),'alternative_population_field_人口数':int(cp['人口数']),'male':int(cp['男']),'female':int(cp['女']),'urban':int(cp['城镇人']),'rural':int(cp['乡村人']),'households':int(cp['户数']),'county_area_km2':float(cp.geometry.area/1e6),'spatial_units':1,'exposure_claim':'No localized exposure count calculated: a single county aggregate cannot locate settlements or exposed persons.'}
# Physics threshold scenarios (parameters assumed, never fitted to unavailable event labels)
sc=[]
for phi in [28,32,36]:
 for cohesion in [0,2000,5000]:
  for sat in [0,.25,.5,.75,1.]:
   theta=np.radians(slope);rho=1800.;depth=1.5;rw=1000.;g=9.81
   fs=(cohesion+(rho-rw*sat)*g*depth*np.cos(theta)**2*np.tan(np.radians(phi)))/(rho*g*depth*np.sin(theta)*np.cos(theta)+1e-12)
   sc.append({'friction_deg':phi,'cohesion_pa':cohesion,'saturation_ratio':sat,'depth_m':depth,'bulk_density_kgm3':rho,'unstable_fraction':float(np.mean(fs[mask]<=1)),'unstable_area_km2':float(np.sum((fs<=1)&mask)*cell**2/1e6)})
pd.DataFrame(sc).to_csv(OUT/'geo_trigger_scenarios.csv',index=False)
theta=np.radians(slope);phi=np.radians(32);rho=1800.;depth=1.5;cohesion=2000.;g=9.81
mcrit=(rho*g*depth*np.cos(theta)**2*np.tan(phi)+cohesion-rho*g*depth*np.sin(theta)*np.cos(theta))/(1000*g*depth*np.cos(theta)**2*np.tan(phi))
summary['physics_threshold']={'interpretation':'Infinite-slope material scenario; not calibrated rainfall threshold and not an ice avalanche model. TWI and 200m slope cannot resolve source shear planes.','default':{'phi_deg':32,'cohesion_pa':2000,'depth_m':1.5,'bulk_density_kgm3':1800,'water_density_kgm3':1000},'critical_saturation_ratio_unclipped':quant(mcrit[mask])}
# PU classification: inventory membership only. Background exclusion 1km, full basin held out, spatial buffer2km.
dist=distance_transform_edt(labels==0,sampling=cell)
positive=valid&(labels>0);background=valid&(labels==0)&(dist>=1000)
pi=np.flatnonzero(positive);ni=np.flatnonzero(background)
# Balanced case/background sample; stratified caps reduce large basin dominance.
pidx=[]
for bid in basin_ids:
 vals=np.flatnonzero(positive&(labels==bid));pidx.extend(RNG.choice(vals,min(120,len(vals)),replace=False).tolist())
pidx=np.array(pidx,dtype=int);nidx=RNG.choice(ni,min(len(pidx),len(ni)),replace=False);idx=np.concatenate([pidx,nidx]);target=np.r_[np.ones(len(pidx),int),np.zeros(len(nidx),int)]
Y,X=np.indices(z.shape);coords=np.c_[xx[X.ravel()[idx]],yy[Y.ravel()[idx]]]
features=np.stack([zn,slope,np.sin(aspect),np.cos(aspect),twi,relief,curv*1e4,land[2023]],axis=-1)
feature_names=['elevation_m','slope_deg','aspect_sin','aspect_cos','twi','tpi_2200m','curvature_x1e4','landcover_code']
F=features.reshape(-1,8)[idx]
# Basin centroid latitude determines fold; background centroid is its own coordinate. Quantile bands equalize positive basins.
centy={int(i+1):float(row.geometry.centroid.y) for i,row in inv.iterrows()}
cut=np.quantile([centy[int(k)] for k in basin_ids],[.25,.5,.75])
folds=np.digitize(coords[:,1],cut)
for j in range(len(pidx)):folds[j]=np.digitize(centy[int(labels.ravel()[idx[j]])],cut)

def model(kind):
 pre=ColumnTransformer([('continuous',StandardScaler(),list(range(7))),('land',OneHotEncoder(handle_unknown='ignore',sparse_output=False),[7])])
 est=LogisticRegression(C=1.,max_iter=1000,random_state=20261023) if kind=='logistic' else ExtraTreesClassifier(n_estimators=300,min_samples_leaf=20,max_features=.8,n_jobs=2,random_state=20261023)
 return make_pipeline(pre,est)
metrics=[];preds=[];importance=[];curves=[]
for fold in range(4):
 test=folds==fold;train=~test
 # Geometric buffer preserves basin exclusion even when polygon spans band boundaries
 near=cKDTree(coords[test]).query(coords[train],k=1)[0]<2000
 tr=np.flatnonzero(train)[~near];te=np.flatnonzero(test)
 if len(np.unique(target[tr]))<2 or len(np.unique(target[te]))<2:continue
 for kind in ['logistic','extratrees']:
  est=model(kind);est.fit(F[tr],target[tr]);pr=est.predict_proba(F[te])[:,1]
  # Default 0.5 on explicitly balanced sample; no event-probability threshold implication.
  auc=roc_auc_score(target[te],pr);ap=average_precision_score(target[te],pr)
  metrics.append({'fold':fold,'model':kind,'train_n':len(tr),'test_n':len(te),'test_positive_n':int(target[te].sum()),'auc':auc,'average_precision':ap,'test_prevalence':float(target[te].mean()),'removed_buffer_n':int(near.sum())})
  for k,t,p in zip(te,target[te],pr):preds.append({'sample_id':int(k),'fold':fold,'model':kind,'target':int(t),'score':float(p),'x':float(coords[k,0]),'y':float(coords[k,1]),'basin_id':int(labels.ravel()[idx[k]])})
  fpr,tpr,_=roc_curve(target[te],pr)
  for a,b in zip(fpr,tpr):curves.append({'model':kind,'fold':fold,'type':'ROC','x':a,'y':b})
  precision,recall,_=precision_recall_curve(target[te],pr)
  for a,b in zip(recall,precision):curves.append({'model':kind,'fold':fold,'type':'PR','x':a,'y':b})
  # Grouped permutation on raw predictor columns, preserving units and one-hot handling.
  for col,name in enumerate(feature_names):
   delta=[]
   for rep in range(10):
    fp=F[te].copy();fp[:,col]=RNG.permutation(fp[:,col]);delta.append(auc-roc_auc_score(target[te],est.predict_proba(fp)[:,1]))
   importance.append({'model':kind,'fold':fold,'feature':name,'auc_drop_mean':float(np.mean(delta)),'auc_drop_sd':float(np.std(delta,ddof=1))})
pd.DataFrame(metrics).to_csv(OUT/'geo_cv_metrics.csv',index=False);pd.DataFrame(preds).to_csv(OUT/'geo_cv_predictions.csv',index=False);pd.DataFrame(importance).to_csv(OUT/'geo_importance.csv',index=False);pd.DataFrame(curves).to_csv(OUT/'geo_cv_curves.csv',index=False)
# Full spatial membership score for visualization, explicitly uncalibrated
selected_model=max(['logistic','extratrees'],key=lambda name:np.mean([r['auc'] for r in metrics if r['model']==name]))
est=model(selected_model);est.fit(F,target);score=np.full(z.shape,np.nan)
score[valid]=est.predict_proba(features[valid])[:,1]
summary['spatial_model']={'target':'polygon-inventory membership versus 1km-buffered unlabeled background','positive_samples':int(len(pidx)),'background_samples':int(len(nidx)),'positive_basins':int(len(basin_ids)),'features':feature_names,'selected_model':selected_model,'model_selection':'Exploratory selection by mean spatial-fold AUROC; not a nested, unbiased final model performance estimate.','design':'4 latitude-band folds; each entire basin assigned by its centroid; training points within 2km of test points removed; balanced case/background sample','fold_cut_y_m':cut.tolist(),'hyperparameters':{'logistic':{'C':1,'max_iter':1000},'extratrees':{'trees':300,'min_samples_leaf':20,'max_features':.8}},'metrics':metrics,'caveats':['Raster pixel test samples are spatially dependent; pixel-wise confidence intervals are invalid. Report fold variability, not binomial precision.','Unlabeled background may contain unrecorded susceptible basins; scores cannot be interpreted as calibrated occurrence probabilities.','DEM epoch uncertain and landcover2023 postdates inventory2020; model is retrospective spatial assessment, not temporal hindcast.','No rainfall/disaster time labels: no validated rainfall critical threshold or actual debrisflow lead-time coverage can be estimated.'],'score_summary':quant(score[valid])}
# Basin summaries: interpretable sample units for plotting
basins=[]
for bid in basin_ids:
 m=mask&(labels==bid);r={'basin_id':int(bid),'code':inv.iloc[int(bid)-1]['Code'],'cells':int(m.sum()),'area_in_dem_km2':float(m.sum()*cell**2/1e6),'elevation_m':float(np.median(zn[m])),'slope_deg':float(np.median(slope[m])),'twi':float(np.median(twi[m])),'critical_saturation_median':float(np.median(mcrit[m]))}
 if np.isfinite(score[m]).any():r['membership_score_mean']=float(np.nanmean(score[m]))
 basins.append(r)
pd.DataFrame(basins).to_csv(OUT/'geo_basin_summary.csv',index=False)
# Glacier direct properties and driving stress (no inferred failure threshold)
nc=xr.open_dataset(next((D/'dataset_4').glob('*.nc')))
gm=np.isfinite(nc.thickness.values)&np.isfinite(nc.v.values);th=nc.thickness.values;vel=nc.v.values;sl=nc.slope.values;drive=917*9.81*th*np.sin(np.radians(sl))
summary['glacier']={'shape':list(th.shape),'resolution_m':30,'crs':'EPSG:32645','valid_ice_cells':int(gm.sum()),'ice_area_km2':float(gm.sum()*900/1e6),'ice_volume_million_m3':float(np.nansum(th)*900/1e6),'thickness_m':quant(th[gm]),'velocity_m_per_year':quant(vel[gm]),'slope_deg':quant(sl[gm]),'driving_stress_pa':quant(drive[gm]),'velocity_period':'ITS_LIVE climatological2014–2024, not a 2026 precursor','thickness_source':'Farinotti et al.2019 consensus estimate','mask_source':'RGI6.0 combining four glacier identifiers; whole mapped volume is not release volume'}
np.savez_compressed(OUT/'geo_glacier.npz',x=nc.x.values,y=nc.y.values,z=nc.dem.values,slope=sl,thickness=th,velocity=vel,driving_stress=drive,mask=gm)
np.savez_compressed(OUT/'geo_grid.npz',x=xx,y=yy,z=z,slope=np.where(mask,slope,np.nan),twi=np.where(mask,twi,np.nan),flowacc=np.where(mask,acc,np.nan),landcover=land[2023],labels=labels,mask=mask,valid=valid,score=score,critical_saturation=np.where(mask,mcrit,np.nan),downstream=down,transform=np.array(list(trans)))
(OUT/'geo_summary.json').write_text(json.dumps(clean(summary),ensure_ascii=False,indent=2))
print(json.dumps(clean({'grid':summary['grid'],'spatial_metrics':metrics,'glacier':summary['glacier']}),ensure_ascii=False,indent=2))
