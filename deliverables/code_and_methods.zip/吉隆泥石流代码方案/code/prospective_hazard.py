"""Prospective Q3 model for FUTURE independently dated event records.

This module is supplied as complete reusable code, but is intentionally not fitted
to the uploaded basin polygons. They contain no disaster occurrence timestamps.
Do not treat image dates, missing labels or synthetic events as real events.
"""
from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

@dataclass
class DiscreteHazard:
    max_iter:int=180
    learning_rate:float=.05
    max_leaf_nodes:int=7
    min_samples_leaf:int=40
    seed:int=20260826

    def fit(self, X, y, *, time, event_id, train_end, monotone=None):
        """X rows are causal at-risk bins with labels observed after issue.

        Each row's time is the target bin end. Caller must remove all at-risk
        rows after first failure and split whole events/basins without leakage.
        Unlabeled times MUST NOT be coded as y=0.
        """
        X=pd.DataFrame(X);y=np.asarray(y)
        t=pd.to_datetime(time)
        if pd.isna(t).any() or set(np.unique(y)) != {0,1}:
            raise ValueError('Need real dated at-risk binary outcomes, including monitored non-events.')
        ids=pd.Series(event_id)
        npositive=ids[y==1].nunique()
        if npositive<20:
            raise ValueError('Fewer than20 independent events: do not claim event-time calibration.')
        keep=t<pd.Timestamp(train_end)
        if y[keep].sum()<10:raise ValueError('Insufficient training events.')
        self.columns=list(X.columns)
        self.model=HistGradientBoostingClassifier(
            max_iter=self.max_iter,learning_rate=self.learning_rate,
            max_leaf_nodes=self.max_leaf_nodes,min_samples_leaf=self.min_samples_leaf,
            l2_regularization=1.,random_state=self.seed,monotonic_cst=monotone)
        self.model.fit(X.loc[keep],y[keep])
        return self

    def distribution(self, future_causal_covariates):
        """Future covariates must be archived forecasts available at issue time.

        Returns failure mass per bin and the explicit non-event residual. Never
        normalize away residual mass to manufacture an apparently certain date.
        """
        X=pd.DataFrame(future_causal_covariates)[self.columns]
        hazard=self.model.predict_proba(X)[:,1]
        survival=np.cumprod(1-hazard)
        prior=np.r_[1.,survival[:-1]]
        mass=prior*hazard
        assert abs(mass.sum()+survival[-1]-1)<1e-10
        return dict(hazard=hazard,mass=mass,survival=survival,non_event_mass=float(survival[-1]))

    def interval(self, future_causal_covariates, target_times, level=.95):
        """Unconditional equal-tail event-time interval; can have +infinity.

        A no-event probability exceeding the upper-tail budget correctly yields
        no finite upper bound. This is a prediction interval, not a parameter CI.
        """
        d=self.distribution(future_causal_covariates);cdf=np.cumsum(d['mass'])
        times=np.asarray(pd.to_datetime(target_times));alpha=1-level
        lower=times[np.searchsorted(cdf,alpha/2)] if cdf[-1]>=alpha/2 else None
        upper=times[np.searchsorted(cdf,1-alpha/2)] if cdf[-1]>=1-alpha/2 else None
        return dict(lower=lower,upper=upper,finite_upper=upper is not None,**d)

def empirical_warning_metrics(events):
    """Input one row per independent held-out event; no fabricated defaults.

    columns actual_time, lower, upper, issued_at, observed, hit_warning.
    Reliability additionally needs monitored non-events to quantify false alarms.
    """
    d=pd.DataFrame(events).copy()
    required=['actual_time','lower','upper','issued_at','observed','hit_warning']
    if any(c not in d for c in required):raise ValueError('Missing event-level validation columns.')
    e=d[d.observed.astype(bool)]
    if len(e)<20:raise ValueError('Event-level interval coverage is unidentifiable/reliably unestimable here.')
    for c in ['actual_time','lower','upper','issued_at']:e[c]=pd.to_datetime(e[c])
    covered=(e.actual_time>=e.lower)&(e.actual_time<=e.upper)
    lead=(e.actual_time-e.issued_at).dt.total_seconds()/3600
    return dict(n_independent_events=len(e),coverage=float(covered.mean()),
                median_lead_hours=float(lead[e.hit_warning.astype(bool)].median()),
                warning_hits=int(e.hit_warning.sum()),
                caveat='Coverage is event conditional. False-alarm evaluation needs monitored non-event windows.')

if __name__=='__main__':
    raise SystemExit('No fit performed: uploaded inventory lacks occurrence-time labels. See README and the paper.')
