#!/usr/bin/env python3
"""Check research-output integrity and substantive numerical/format contracts.

Does not certify event forecasting, publication acceptance, or visual perfection.
Use --allow-incomplete-paper while manuscript generation is still in progress.
"""
from __future__ import annotations
import argparse,json,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if (ROOT/'vendor').is_dir():sys.path.insert(0,str(ROOT/'vendor'))
import numpy as np
import pandas as pd
from PIL import Image
from lxml import etree

R=ROOT/'results';P=ROOT/'manuscript'
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'm':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
checks=[]

def check(name,condition,details=None):
    checks.append(dict(name=name,passed=bool(condition),details=details))

def load(name):
    f=R/name
    if not f.exists():
        check('result_exists:'+name,False);return None
    check('result_exists:'+name,True,dict(bytes=f.stat().st_size))
    return json.loads(f.read_text(encoding='utf-8'))

def validate_science():
    met=load('met_summary.json');geo=load('geo_summary.json');trig=load('trigger_summary.json');sim=load('sim_summary.json')
    if met:
        check('hourly_calendar_nonempty',met.get('n_hourly_rows',0)>1000,met.get('n_hourly_rows'))
        check('five_descriptive_features',len(met.get('top5',[]))==5)
        pred=met['forecast'];check('proxy_target_explicit','temperature' in pred['target'].lower() and 'not' in pred['target'].lower(),pred['target'])
        for key in ['point_coverage','daily_simultaneous_coverage']:
            check('coverage_range:'+key,0<=pred[key]<=1,pred[key])
        forecast=pd.read_csv(R/'met_temperature_forecast.csv')
        actual=((forecast.observed>=forecast.lower)&(forecast.observed<=forecast.upper)).mean()
        check('coverage_matches_forecast_pairs',abs(actual-pred['point_coverage'])<1e-10,float(actual))
        check('positive_interval_width',(forecast.upper>=forecast.lower).all())
        check('forecast_strict_horizon',((pd.to_datetime(forecast.target_time)-pd.to_datetime(forecast.issue_time)).dt.total_seconds()==21600).all())
    if geo:
        check('spatial_target_not_occurrence','not' in geo.get('scope','').lower(),geo.get('scope'))
        with np.load(R/'geo_grid.npz') as a:
            mask=a['mask'];outlet=mask&(a['downstream']<0)
            err=abs(float(a['flowacc'][outlet].sum())-int(mask.sum()))
            check('D8_contributing_area_conservation',err<1e-8,err)
            theta=np.radians(a['slope']);m=a['critical_saturation']
            fs=(2000+(1800-1000*m)*9.81*1.5*np.cos(theta)**2*np.tan(np.radians(32)))/(1800*9.81*1.5*np.sin(theta)*np.cos(theta))
            residual=float(np.nanmax(abs(fs[mask]-1)))
            check('geographic_critical_saturation_FS_residual',residual<.02,residual)
    if trig:
        p=trig['parameters'];errors=[]
        for case in trig['cases']:
            b=np.radians(case['beta_deg']);m=case['m_critical']
            fs=(p['c_pa']+(p['rho_s']-p['rho_w']*m)*p['g']*p['z_m']*np.cos(b)**2*np.tan(np.radians(p['phi_deg'])))/(p['rho_s']*p['g']*p['z_m']*np.sin(b)*np.cos(b))
            errors.append(abs(float(fs)-1))
        check('analytic_trigger_FS_equals_one',max(errors)<1e-10,max(errors))
    if sim:
        meta=sim.get('meta',{});check('simulation_scenario_label',meta.get('scenario_not_calibrated') is True)
        ref=sim.get('reference_scenario',{})
        check('reference_simulation_volume_balance',abs(ref.get('relative_mass_error',np.inf))<1e-7,ref.get('relative_mass_error'))
        scenario=pd.read_csv(R/'sim_scenarios.csv')
        if 'relative_mass_error' in scenario:
            maximum=float(scenario.relative_mass_error.abs().max())
            check('all_scenarios_volume_balance',maximum<1e-7,maximum)
        tests=sim.get('numerical_verification',{})
        check('simulation_numerical_verification_recorded',bool(tests),tests)
        # Read evidence from the evolving solver without hardcoding an old scheme.
        # Static-pile information must not be silently omitted from validation.
        static={k:v for k,v in tests.items() if any(s in k.lower() for s in ['static','pile','subyield'])}
        check('static_pile_verification_recorded',bool(static),static)
        for k,v in static.items():
            if isinstance(v,(int,float)) and any(s in k.lower() for s in ['drift','error','discharge','velocity','speed']):
                check('static_pile_stationary:'+k,abs(v)<1e-7,v)
        for k,v in tests.items():
            if isinstance(v,(int,float)) and ('error' in k.lower()) and ('relative' in k.lower() or 'lake_at_rest' in k.lower()):
                check('numerical_verification:'+k,abs(v)<1e-7,v)

def validate_figures():
    manifest=load('figure_manifest.json')
    if not manifest:return
    check('multiple_standalone_figures',len(manifest)>=8,len(manifest))
    for item in manifest:
        stem=item['stem'];tif=ROOT/item['tiff'];eps=ROOT/item['eps']
        check('figure_pair_exists:'+stem,tif.is_file() and eps.is_file())
        if tif.exists():
            with Image.open(tif) as im:
                dpi=im.info.get('dpi',(0,0));alpha=im.getchannel('A').getextrema() if im.mode=='RGBA' else None
                check('tiff_RGBA_600_transparency:'+stem,im.mode=='RGBA' and all(abs(float(x)-600)<1 for x in dpi) and alpha[0]==0,dict(mode=im.mode,dpi=[float(x) for x in dpi],size=im.size,alpha=alpha))
        if eps.exists():
            with eps.open('rb') as f:head=f.read(1000).decode('ascii','replace')
            check('eps_postscript_header:'+stem,head.startswith('%!PS-Adobe') and 'EPSF' in head)
        check('minimum_source_font:'+stem,float(item.get('font_min_pt',0))>=14)

def validate_paper(allow_incomplete=False,allow_missing_pdf=False):
    doc=P/'吉隆灾害链建模论文.docx';pdf=P/'吉隆灾害链建模论文.pdf'
    if not doc.exists() and allow_incomplete:
        checks.append(dict(name='paper_generation',passed=True,details='Not yet generated; explicitly allowed.'))
        return
    check('docx_exists',doc.is_file())
    if doc.exists():
        with zipfile.ZipFile(doc) as z:
            xml=etree.fromstring(z.read('word/document.xml'))
            maths=xml.xpath('//m:oMath',namespaces=NS)
            texts=''.join(xml.xpath('//w:t/text()',namespaces=NS))
            check('native_editable_OMML',len(maths)>20,len(maths))
            check('no_raw_inline_dollar_latex',not bool(re.search(r'\$[^$\n]{1,500}\$',texts)))
            check('no_unrendered_latex_commands',not any(x in texts for x in [r'\frac{',r'\begin{equation}',r'\mathrm{']))
            tables=xml.xpath('//w:tbl',namespaces=NS)
            check('three_line_tables_present',len(tables)>0,len(tables))
            all_tables=True
            for t in tables:
                visible=t.xpath('.//w:tcBorders/*[@w:val="single"]',namespaces=NS)
                if not visible or any(v.get('{'+NS['w']+'}sz')!='27' or v.get('{'+NS['w']+'}color')!='000000' for v in visible):all_tables=False
                cells=t.xpath('.//w:tc/w:p',namespaces=NS)
                if any(not p.xpath('./w:pPr/w:jc[@w:val="center"]',namespaces=NS) for p in cells):all_tables=False
            check('table_lines_2_25pt_black_and_centered',all_tables)
            check('body_page_number_starts_at_one',bool(xml.xpath('//w:sectPr/w:pgNumType[@w:start="1"]',namespaces=NS)))
            check('no_replacement_glyph_in_docx','\ufffd' not in texts)
    if not pdf.exists() and (allow_incomplete or allow_missing_pdf):
        checks.append(dict(name='pdf_generation',passed=True,details='PDF absence explicitly allowed; no PDF readiness claim.'));return
    check('pdf_exists',pdf.is_file())
    if pdf.exists():
        import fitz
        with fitz.open(pdf) as d:
            check('substantial_pdf_and_extractable_chinese',len(d)>=5 and '高寒' in d[0].get_text(),dict(pages=len(d)))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--allow-incomplete-paper',action='store_true')
    ap.add_argument('--allow-missing-pdf',action='store_true')
    args=ap.parse_args()
    validate_science();validate_figures();validate_paper(args.allow_incomplete_paper,args.allow_missing_pdf)
    failed=[x for x in checks if not x['passed']]
    record=dict(passed=not failed,checks=checks,failures=failed,
                limitation='Artifact checks do not establish empirical disaster forecasting skill or replace manual page/figure inspection.')
    (R/'validation_report.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(passed=not failed,n_checks=len(checks),failures=failed),ensure_ascii=False,indent=2))
    if failed:raise SystemExit(1)

if __name__=='__main__':main()
