"""Q2: transparent parameterized physical threshold, NOT a calibrated trigger.

The infinite-slope equation is applicable to shallow soil slopes, not to a
fracturing glacier. All material and hydrological parameters below are scenarios.
Rainfall intensity is gross hourly rainfall before a fixed infiltration cap.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results'

PARAMETERS = dict(g=9.80665, rho_s=1800., rho_w=1000., c_pa=2000.,
                  phi_deg=32., z_m=1.5, porosity=.40, m0=.35,
                  tau_h=72., infiltration_cap_mmh=20.)

def critical_saturation(beta_deg, **kw):
    p = PARAMETERS | kw
    b = np.deg2rad(beta_deg)
    ph = np.deg2rad(p['phi_deg'])
    nz = p['rho_s'] * p['g'] * p['z_m'] * np.cos(b)**2
    tau = p['rho_s'] * p['g'] * p['z_m'] * np.sin(b)*np.cos(b)
    return (p['c_pa'] + nz*np.tan(ph)-tau)/(p['rho_w']*p['g']*p['z_m']*np.cos(b)**2*np.tan(ph))

def factor_of_safety(beta_deg, m, **kw):
    p = PARAMETERS | kw
    b = np.deg2rad(beta_deg)
    sigma = p['rho_s']*p['g']*p['z_m']*np.cos(b)**2
    pore = m*p['rho_w']*p['g']*p['z_m']*np.cos(b)**2
    return (p['c_pa']+(sigma-pore)*np.tan(np.deg2rad(p['phi_deg'])))/(p['rho_s']*p['g']*p['z_m']*np.sin(b)*np.cos(b))

def critical_intensity(beta_deg, duration_h, **kw):
    p = PARAMETERS | kw
    m = critical_saturation(beta_deg, **kw)
    e = np.exp(-np.asarray(duration_h)/p['tau_h'])
    depth_mm = p['porosity']*p['z_m']*1000
    req = np.maximum(0, depth_mm*(m-p['m0']*e)/(p['tau_h']*(1-e)))
    # The soil cannot reach m>1 by rainfall saturation; the cap bounds infiltration.
    possible = (m <= 1) & (req <= p['infiltration_cap_mmh'])
    # If initially unstable, the first-passage rainfall threshold is already zero.
    return np.where(m <= p['m0'], 0., np.where(possible, req, np.nan))

def main():
    OUT.mkdir(exist_ok=True)
    betas = np.linspace(15,45,121)
    durations = np.geomspace(1,72,150)
    curve = pd.DataFrame({'slope_deg':betas,'critical_m':critical_saturation(betas),
                          'FS_dry':factor_of_safety(betas,0),
                          'FS_saturated':factor_of_safety(betas,1)})
    curve.to_csv(OUT/'trigger_critical_slope.csv',index=False,encoding='utf-8-sig')
    rows = []
    for beta in [25,28,30,32,35]:
        for d,q in zip(durations,critical_intensity(beta,durations)):
            rows.append(dict(slope_deg=beta,duration_h=float(d),critical_intensity_mmh=float(q),
                             reachable=bool(np.isfinite(q))))
    pd.DataFrame(rows).to_csv(OUT/'trigger_intensity_duration.csv',index=False,encoding='utf-8-sig')
    cases=[]
    for beta in [25,28,30,32,35]:
        cases.append(dict(beta_deg=beta,m_critical=float(critical_saturation(beta)),
                          FS_initial=float(factor_of_safety(beta,PARAMETERS['m0'])),
                          I24_mmh=float(critical_intensity(beta,24))))
    # Perturb only hypothetical material parameters: this is NOT confidence.
    sensitivity=[]
    for c in [0,2000,5000]:
        for phi in [28,32,36]:
            sensitivity.append(dict(c_kpa=c/1000,phi_deg=phi,
                                    m_critical_beta30=float(critical_saturation(30,c_pa=c,phi_deg=phi))))
    pd.DataFrame(sensitivity).to_csv(OUT/'trigger_material_sensitivity.csv',index=False,encoding='utf-8-sig')
    summary=dict(parameters=PARAMETERS,cases=cases,
        critical_dry_slope_deg=brentq(lambda b:factor_of_safety(b,0)-1,5,70),
        critical_saturated_slope_deg=brentq(lambda b:factor_of_safety(b,1)-1,5,70),
        interpretation='Illustrative shallow-soil infinite-slope + linear reservoir; not calibrated thresholds; not an ice-collapse fracture model.',
        proof='Analytic m(t)=m0 exp(-t/tau)+Ieff*tau/(1000*n*z)*(1-exp(-t/tau)); threshold m(t)=mcrit; 0<=m<=1.',
        limitations=['No measured cohesion/friction/hydraulic conductivity; no event-time labels for calibration.',
                     'VWC sensor is not a pore-pressure measurement and m is not directly VWC.',
                     'Station rainfall cannot establish high-elevation source-zone rainfall.',
                     'Thresholds assume fixed soil and constant rainfall; cannot forecast actual debris-flow trigger.'])
    (OUT/'trigger_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
