"""Combine derived methods with computed tables, figures and interpretations."""
from pathlib import Path
import json,re,math
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'results';M=ROOT/'manuscript'

def load(name):return json.loads((R/name).read_text())
def p(s):return dict(type='p',text=s)
def h(s):return dict(type='h2',text=s)
def t(title,headers,rows):return dict(type='table',title=title,headers=headers,rows=rows)
def fmt(x,n=3):
    if x is None or not np.isfinite(float(x)):return '不可估计'
    return f'{x:.{n}f}'

def main():
    met=load('met_summary.json');geo=load('geo_summary.json');sim=load('sim_summary.json');tr=load('trigger_summary.json');ext=load('ext_summary.json')
    base=json.loads((M/'methods_blocks.json').read_text())
    raw=load('figure_manifest.json')
    figs=raw['figures'] if isinstance(raw,dict) and 'figures' in raw else raw
    if isinstance(figs,dict):figs=list(figs.values())
    def figureblocks(section):
        out=[]
        for f in figs:
            if f.get('section')!=section:continue
            f=dict(f);f['type']='figure'
            # Prefer transparent600dpi lossless raster embedded in DOCX.
            if f.get('tiff'):f['file']=f['tiff'];f.pop('png',None)
            elif f.get('files',{}).get('tiff'):f['file']=f['files']['tiff'];f.pop('png',None)
            out.append(f)
        return out
    extras={}
    extras[2]=[
        h('2.5 附件审计结果与证据等级'),
        t('数据清单、有效范围与可支持结论',['数据','实际可用内容','关键限制'],[
            ['（1）MET/RADM/SOIL/FLUX','各52,584个小时标签；有效观测主要止于2026年8月27日','全年时间网格后段缺测；时区、站点精确位置与QC码本未给出'],
            ['（2）五县逐日气温','2005年1月1日至2025年8月2日，共7,519日','2025不完整，排除年度趋势回归'],
            ['（3）200千米冰川RAR','未取得数值','上传文件超过工具32 MiB单文件传输上限'],
            ['（4）冰川地形、冰厚、速度','30米网格；冰川6.4368平方千米','速度为2014—2024气候态；冰厚为估算'],
            ['（5）土地覆盖','2020—2023四期，原始编码1—10','无类别图例，保留原编码'],
            ['（6）历史灾点','84个沟域多边形，DEM范围内23个','影像/解译日期不能作为真实发生时间'],
            ['（7）DEM','约30米地理坐标网格；分析重投影至UTM45N','获取时点不明，不能预设为灾前DEM'],
            ['（8）人口普查','单个县域多边形，合计17,536人','不含居民点分布，不能细化暴露人数']]),
        p('附件编号与赛题提供顺序一致。所有原始文件以只读数据源使用，缺测不转成零；重采样、特征构造和模型评分均保存中间文件。地形、土地覆盖与灾害沟域的空间交集决定模型实际适用域，不把不同覆盖范围的面积直接相除。冰川全域存量与释放体积、县级人口与局部暴露人口是不同物理量。'),
        t('主要符号与量纲',['符号','定义','量纲'],[
            [r'$P_{t,k}$','截至时刻t的k小时累计降雨','毫米'],[r'$T_t$','2米气温','摄氏度'],
            [r'$A_{t,k}$','k小时正积温','摄氏度·日'],[r'$R_{n,t}$','地表净辐射','瓦/平方米'],
            [r'$\theta_t$','体积含水率','立方米/立方米'],[r'$m$','饱和水层厚度与垂直土层厚度之比','无量纲'],
            [r'$\beta,\phi$','坡角、有效内摩擦角','弧度（展示时用度）'],[r'$F_s$','抗剪强度与驱动剪应力之比','无量纲'],
            [r'$h$','等效流层厚度','米'],[r'$q_x,q_y$','单位宽度流量','平方米/秒'],
            [r'$\mu$','库仑阻力系数','无量纲'],[r'$\xi$','Voellmy湍流阻力参数','米/平方秒'],
            [r'$\lambda_{b,t}$','沟域b在t时间箱内的条件灾害风险率','无量纲'],[r'$S_{b,t}$','离散生存函数','无量纲']]),
        p('软件中对有QC列的变量仅保留QC=0，是缺少码本时事先规定的保守操作规则，不把它表述为数据生产方已核实的质量等级。将绝对值不小于9990的哨兵值转为缺测；气温限定−60至50℃、相对湿度0至100%、体积含水率0至1、风速0至60米/秒、小时降水0至150毫米。辐射短波中−20至0瓦/平方米的小负值按夜间仪器偏差截为零，超界值删除；全部规则与删失量可在代码和变量审计CSV中核对。')
    ]+figureblocks('audit')
    top=met['top5'];fc=met['forecast'];rank=pd.read_csv(R/'met_feature_ranking.csv')
    rankrows=[]
    for d in top:
        row=rank[rank.feature.eq(d['feature'])].iloc[0]
        rankrows.append([d['name'],fmt(d['event_value']),fmt(d['robust_z']),f"[{fmt(d['z_lo'])}, {fmt(d['z_hi'])}]",fmt(100*row['top5_bootstrap_probability'],1)+'%'])
    extras[3]=[
        h('3.6 事件窗口的实测结果及前五特征解释'),
        p('以赛题给出的2026年8月26日10时30分为参考事件标签，只使用截至10时的完整小时观测。主分析先构造各个小时物理特征，再对其取尾随24小时均值，至少需要20个有效小时。对照为2021—2025年8月26日前后各15天、同为10时结束的窗口，每年31个，共最多155个。对照窗口相互重叠且存在年际异质性，因此采用按年份整簇重抽，而不以155个窗口冒充155个独立灾害事件。'),
        t('指定统计口径下的前五描述性异常关联',['特征','事件均值','稳健Z','年簇95%区间','前五入选率'],rankrows),
        p('表中的事件均值按各指标本来的量纲给出：含水率为立方米/立方米，气温为摄氏度，积温为摄氏度·日，净辐射为瓦/平方米。这里的“24小时正积温”和“72小时正积温”先在逐小时构造，再对衍生序列取24小时均值，故分别得到13.419和39.152；它们不同于10时直接读取的累计积温13.784和39.745。统一这种双层时间聚合口径可避免图表与原始瞬时特征看似矛盾。'),
        p('40厘米含水率的标准化差异最大，但历史经验分位数仅68.39%，年簇区间跨零且延伸至14.30，95%排名范围约为1—19；因此它是本次指定统计量的首位，而不是稳定、普适的首要致灾因素。气温的经验分位为96.13%，异常更稳定；其与24小时正积温的对照Spearman相关系数约0.920，说明两个高排名特征共享热力信息，不能把重复信息解释成两个独立因果驱动。代码保留全部原始排名，并另外输出相关矩阵和冗余家族，避免为追求五个“高级因素”而任意改名或替换。'),
        p('事件前24小时平均气温为13.784℃、净辐射190.112瓦/平方米、感热通量48.951瓦/平方米、潜热通量44.526瓦/平方米。1—20米温度梯度均值约−0.03467℃/米，这是近地层梯度，不能外推为自由大气直减率。体积理查森数有效23小时，其中19小时为负，占82.61%，支持测站多数时段近地层不稳定的描述；观测高度仅1—20米，无法据此反演完整大气边界层顶高度。'),
        p('最有辨识力的反证是：截至事件前最后完整小时，本站24和72小时累计降雨均为0毫米，且相应窗口通过逐小时完整性检查。因此本研究不能将“本站暴雨”写成已证实触发条件。该结果不排除高位源区降雪、局地降雨、冰川内部水压或融水输入，也不等于泥石流无需水源；它说明测站与源区之间的空间代表性是当前推断链中的关键缺口。')
    ]+figureblocks('q1')+[
        h('3.7 长期气温背景与窗口敏感性'),
        t('2005—2024完整年份的稳健年均气温趋势',['县域','年数','℃/10年','95%区间','Kendall检验p'],[
            [d['station'],d['n_years'],fmt(d['slope_C_decade']),f"[{fmt(d['slope_lo'])}, {fmt(d['slope_hi'])}]",fmt(d['p_value'])] for d in met['temperature_history']['trends']]),
        p('五县趋势估计均为正，但95%区间全部跨越零，5%水平下均未达到显著性。吉隆估计为每10年0.130℃，区间为−0.769至1.185℃，不能写成“显著升温导致灾害”。2025仅覆盖至8月2日，若直接与完整年份年均温比较，会把暖季偏置误当成长期趋势，故年度推断仅使用不少于350日的年份。长期背景、事件异常与因果归因分别回答不同问题，本文保持三者边界。'),
        p('6、12、24和48小时聚合窗口的排序对比以及年簇重抽概率表明：部分热力特征相对稳定，含水率首位不稳定。由于独立年份仅5个，重抽次数1,200提升的是数值近似精度，并未增加独立样本数。对多个候选特征同时探索时，排序属于描述性发现；没有执行独立灾害标签上的多重检验或因果识别，不能使用“已证实”措辞。')]
    metrics=geo['spatial_model']['metrics'];gr=pd.read_csv(R/'geo_trigger_scenarios.csv')
    basegr=gr[np.isclose(gr.friction_deg,32)&np.isclose(gr.cohesion_pa,2000)]
    extras[4]=[
        h('4.8 空间验证、临界参数与冰川源区的实际结果'),
        t('四折缓冲空间验证的成员判别结果',['空间折','训练样本','测试样本','逻辑回归AUC','ExtraTrees AUC'],[
            [i+1,next(d['train_n'] for d in metrics if d['fold']==i),next(d['test_n'] for d in metrics if d['fold']==i),fmt(next(d['auc'] for d in metrics if d['fold']==i and d['model']=='logistic'),4),fmt(next(d['auc'] for d in metrics if d['fold']==i and d['model']=='extratrees'),4)] for i in range(4)]),
        p('共同地形—土地覆盖域内抽取2,099个沟域内正例与2,099个距沟域边界至少1千米的未标记背景。四折按纬向空间带划分，并以沟域质心将同一沟域整体留出；训练样本距任一测试样本小于2千米时进一步删除。逻辑回归四折平均AUC为'+fmt(np.mean([d['auc'] for d in metrics if d['model']=='logistic']),4)+'，ExtraTrees为'+fmt(np.mean([d['auc'] for d in metrics if d['model']=='extratrees']),4)+'。复杂树模型在某些空间带有较高值，但跨带稳定性较弱，因此最终成员评分图选用正则化逻辑回归。模型选择也使用了这些折，所得指标是探索性比较，并非嵌套验证后的无偏最终泛化性能。'),
        p('成员评分的本义是“与已编录沟域的环境相似程度”。背景未被长期监测为绝对安全，且正负抽样比例人为设为1∶1，故评分0.8不表示80%的泥石流发生概率。图中的高值区可支持踏勘与监测优先级安排，但不能直接设为撤离概率阈值。土地覆盖2023晚于2020解译，DEM获取时点不明，因此本项属于回顾性空间评估，不构成灾前时序回测。'),
        t('无限边坡基准情景的区域敏感性',['饱和比','安全系数≤1面积/km²','占有效DEM比例'],[
            [fmt(d.saturation_ratio,2),fmt(d.unstable_area_km2,2),fmt(100*d.unstable_fraction,2)+'%'] for d in basegr.itertuples()]),
        p('基准参数取垂直土层厚度1.5米、黏聚力2千帕、摩擦角32°、混合土密度1,800千克/立方米。这些来自情景设定而非现场标定。地理栅格计算采用重力加速度9.81米/平方秒，解析阈值演示采用9.80665米/平方秒；两者仅为数值取位差异，原始脚本分别保留以便复核。干燥时满足安全系数不大于1的面积约399.72平方千米，占22.88%；饱和时约1,248.20平方千米，占71.46%。比例的变化说明同一地形下孔压对抗剪余量的影响，不表示71.46%的区域将发生灾害，更不等于实际淹没面积。临界饱和比中位数约0.5628，其小于零或大于一的值分别表示该组参数下初始已不稳定或单纯饱和不足以致稳态失稳，应保留物理含义而不全部截断。'),
        t('浅层土坡水力—稳定性解析阈值情景',['坡角/°','临界饱和比','初始安全系数','持续24h临界雨强/mm·h⁻¹'],[
            [d['beta_deg'],fmt(d['m_critical']),fmt(d['FS_initial']),fmt(d['I24_mmh'])] for d in tr['cases']]),
        p('解析雨强使用初始饱和比0.35、孔隙率0.40、退水时间72小时及入渗上限20毫米/小时。30°坡面的临界比为0.427、24小时临界雨强约5.180毫米/小时；32°和35°在给定初态下已经不稳定，故首次越阈的额外雨强为零，而不是再拟合一个正阈值。若计算所需入渗超过上限，或临界比大于1，程序返回不可达而非虚构数值。它们解释如何由物理参数推得条件阈值，不是吉隆已验证的实测降雨预警标准。'),
        p('冰川掩膜面积为6.4368平方千米，冰厚中位43米，按网格体积求和的全域估计存量为3.19182亿立方米。该量含估计误差，并非本次冰崩体积。表面速度中位2.028米/年代表2014—2024气候态，不能据此宣称2026灾前加速。驱动应力中位约131.24千帕，可用于挑选相对高应力监测区；没有裂隙、基底水压与多年时变速度时，不能从单幅驱动应力图确定崩塌日期。'),
        p('土地覆盖2020与2023共同有效域为8,808.29平方千米，类别编码变化面积488.89平方千米，占约5.55%。没有原始图例时，不能把代码1擅自写成耕地或把某次编码转移断言为城市扩张。县域人口合计17,536，与男性9,338和女性8,198、城镇5,015与乡村12,521均相符；另一个“人口数”字段为16,155，统计口径不明，本文采用可由分项验证的合计，但不把人口平均撒入地形网格并伪装成实测暴露人口。')
    ]+figureblocks('q2')+[
        h('4.9 外部遥感与气象补充：已完成的技术核查和剩余条件'),
        p('赛题第二问明确允许并要求自行补充卫星与天气预报资料。已编写公开接口采集脚本并请求Open-Meteo历史气象、Element84 Sentinel-2 STAC目录，但两个接口及Crossref服务在HTTPS代理CONNECT阶段返回403，未取得新增数值。已把archive-api.open-meteo.com、earth-search.aws.element84.com和api.crossref.org加入保留既有规则的环境配置草稿；保存草稿不等于运行网络策略已经更新。不能把已写采集代码说成外部数据已补齐，也不能把再分析资料标成当时可获得的业务预报。'),
        p('允许访问后，应按每个卫星资产给出的比例因子和偏置还原反射率，尤其注意Sentinel-2自2022年以来的处理基线偏置；不能一律把DN除以10,000。云、卷云、阴影与雪分别掩膜，在同一有效域提取NDVI、NDSI及其事件前变化。所有输入必须记录观测时刻、发布时刻、下载时刻；真实回测仅接纳发布时刻不晚于起报时刻的资料。现阶段数值模型没有使用这些未取得的特征，因此新增遥感与天气预报对第二、三问的增益仍未验证。')]
    extras[5]=[
        h('5.7 已执行的代理预测实验与真实预警的可识别边界'),
        t('6小时超前气温区间预测的独立年度测试',['项目','计算结果'],[
            ['训练/校准/测试','2021—2023 / 2024 / 2025'],['测试逐时对数',fc['test_n']],['校准完整目标日数',fc['calibration_blocks']],
            ['测试完整目标日数',fc['test_blocks']],['气温MAE/℃',fmt(fc['temperature_MAE_C'])],['持续性MAE/℃',fmt(fc['persistence_MAE_C'])],
            ['原始逐时区间覆盖',fmt(100*fc['raw_point_coverage'],2)+'%'],['校准后逐时覆盖',fmt(100*fc['point_coverage'],2)+'%'],
            ['整日同时覆盖',fmt(100*fc['daily_simultaneous_coverage'],2)+'%'],['整日Wilson区间',f"[{fmt(100*fc['daily_coverage_wilson_95'][0],2)}%, {fmt(100*fc['daily_coverage_wilson_95'][1],2)}%]"],
            ['平均区间宽/℃',fmt(fc['mean_width_C'])]]),
        p('模型采用三个分位数的直方图梯度提升回归，最大180轮、学习率0.06、最多15个叶节点、最小叶样本40、L2系数1。输入仅为起报时刻可获得的气温滞后0、1、3、6、12、24、48小时，以及当时湿度、6小时雨量、浅层含水率、净辐射、风速和周期日历变量；目标为6小时后的本站2米气温。训练、校准和测试按目标时刻切分，禁止跨年边界目标泄漏。'),
        p('校准以目标日期组成非重叠24小时完整日，对每日最大不符合分数取有限样本上分位顺序统计量。362个校准完整日对应第345个次序值，修正量约2.536℃。测试365日中348日全部24个目标均被覆盖，整日同时覆盖95.34%；逐时覆盖99.55%回答的是不同问题，不能互换。校准平均区间宽12.14℃，显示高覆盖以较宽区间为代价。Wilson区间假设独立日，仅作为近似描述；日际依赖和分布漂移使严格交换性保证不成立。'),
        p('与持续性预测相比，测试MAE从5.594℃降至1.411℃，说明该实现能学习测站日变化，并为热力风险驱动量提供可复现的区间预测基线。然而气温预测的6小时超前量不是泥石流预警提前量，气温95.34%整日覆盖不是灾害触发时间95%覆盖，更不是“已实现95%可靠预报”。本文不使用这项代理成绩替代题目第三问所需的真实事件级验证。')
    ]+figureblocks('q3')+[
        t('第三问四项要求在当前证据下的状态',['要求','当前可报告内容','尚需条件'],[
            ['触发时间95%区间','给出风险率—生存函数及校准算法；未产生实灾区间','独立发生时间、持续监测非事件与当时可得预报'],
            ['预警提前量','气温代理为6小时；无实灾业务提前量','明确起报时刻、阈值、数据延迟与实际灾害时刻'],
            ['区间覆盖率','气温代理整日95.34%；实灾覆盖不可识别','多事件独立测试，完整纳入漏报事件'],
            ['空间距离范围','给出空间评分域；仿真径向范围仅属情景','源区定位、传播校准、监测点及暴露对象坐标']]),
        p('附带prospective_hazard.py实现离散时间风险率、带“本时域不发生”剩余概率的生存分布以及事件级预警评价接口。该模块要求真实独立事件和受监测非事件数据，当前附件不满足时会明确拒绝拟合。保留无事件质量非常必要：若未来时域内发生概率不足97.5%，无条件等尾区间的上界可以无穷，不能为了输出某个日期而强行把质量归一化到必然发生。这个接口属于待补数据后可执行的扩展，不计入已训练模型。')]
    extras[6]=[
        h('6.7 参数、数值检验与仿真结果的可解释范围'),
        p('仿真采用真实DEM和冰川掩膜，源区通过冰厚与坡度的客观指标选择，释放比例、阻力参数及初态为情景设定。以下各数值直接读取本次执行的sim_summary.json和CSV；模型适用条件、数值平衡检查及网格敏感性决定可解释范围，不能仅因质量守恒接近机器精度就认定灾害路径已被重现。')]
    # Final simulation schema may be updated after an independent physical review.
    meta=sim.get('meta',{});ref=sim.get('reference_scenario',{})
    extras[6]+=[t('仿真基准参数与来源',['参数','数值','属性'],[
        ['网格间距',str(meta.get('dx_m'))+'米','DEM重投影后的计算尺度'],
        ['模拟时长',str(meta.get('duration_s'))+'秒','数值试验时域'],
        ['释放比例',str(ref.get('fraction')),'未标定情景'],
        ['库仑系数',str(ref.get('mu')),'未标定情景'],
        ['Voellmy参数',str(ref.get('xi_ms2'))+'米/平方秒','未标定情景'],
        ['CFL数',str(meta.get('CFL')),'稳定性控制'],
        ['释放体积',fmt(ref.get('initial_volume_m3',float('nan'))/1e6,3)+'百万立方米','掩膜厚度积分乘释放比例；非实测崩塌量']])]
    extras[6]+=[t('参考情景数值结果（不等于实灾预报）',['指标','数值','解释'],[
        ['累计影响面积/km²',fmt(ref.get('footprint_km2')),'由计算流深阈值界定'],
        ['最大径向距离/km',fmt(ref.get('max_distance_from_source_km')),'源区到计算单元中心距离，非沿沟路程'],
        ['全过程峰速/m·s⁻¹',fmt(ref.get('peak_speed_ms')),'带湿深阈值的数值场诊断'],
        ['首次越过1km诊断圆/s',fmt(ref.get('first_1km_crossing_s')),'不是口岸到达时刻'],
        ['质量相对误差',f"{ref.get('relative_mass_error',float('nan')):.2e}",'仅验证离散质量账本']])]
    verification=sim.get('numerical_verification',{})
    extras[6]+=[p('数值检验的原始指标为：'+ '；'.join(k+'='+str(v) for k,v in verification.items())+'。这些检查分别针对静水平衡、摩擦静止、非负性和守恒。静态堆积体在阻力足以抵消坡面驱动时应保持零通量；若流量为零而前缘仍外扩，说明数值扩散正在移动质量，不能将其解释成物理传播。最终代码将该检查作为必要诊断。')]
    if (R/'sim_grid_sensitivity.csv').exists():
        gd=pd.read_csv(R/'sim_grid_sensitivity.csv')
        cols=[c for c in ['dx_m','resolution_m','first_1km_crossing_s','max_distance_from_source_km','relative_mass_error'] if c in gd]
        labels={'dx_m':'网格/m','resolution_m':'网格/m','first_1km_crossing_s':'1km首达/s','max_distance_from_source_km':'径向距离/km','relative_mass_error':'质量相对误差'}
        extras[6]+=[t('等初始体积的网格敏感性',[labels[c] for c in cols],[[f'{x:.3g}' if isinstance(x,(float,np.floating)) else str(x) for x in row] for row in gd[cols].itertuples(index=False,name=None)])]
    ss=pd.read_csv(R/'sim_scenarios.csv')
    extras[6]+=[t('十一组释放—阻力情景的完整计算摘要',['比例','库仑系数','湍阻参数','距离/km','峰速/m·s⁻¹','1km首达/s'],[
        [fmt(d.fraction,2),fmt(d.mu,2),str(int(d.xi_ms2)),fmt(d.max_distance_from_source_km),fmt(d.peak_speed_ms),fmt(d.first_1km_crossing_s) if np.isfinite(d.first_1km_crossing_s) else '600s内未达'] for d in ss.itertuples()]),
        p('在释放比例相同的情景间比较库仑系数，可区分阻力对传播的影响；在阻力相同的情景间比较释放比例，可区分初始供给的影响。额外两个湍阻参数情景只作为局部敏感性检查，不能支撑独立估计全部全局敏感度指标。11组中10组在600秒内越过1千米诊断圆，1组未达，属于时域右删失。仅在已到达的10组中计算的到达时2.5%—97.5%分位约为16.416—32.842秒，既不是全部情景的无条件到达区间，也不是校准后的灾害预报区间。'),
        p('最终参考情景峰值48.193米/秒、最大流深50.566米，600秒内累计影响面积3.330平方千米、最大径向覆盖距离3.487千米。600秒末仍存在流动，故不能称为最终停止或堆积距离。75与150米网格的1千米首达相差约2.4%、径向覆盖相差约1.3%；300米网格首达仅16秒，说明粗网格偏差显著。速度和流深并未展示全面、单调的网格收敛，本文不据此给出工程级到达时刻。')]
    extras[6]+=figureblocks('q4')+[
        p('参数集合的2.5%—97.5%分位数只反映选定释放量与阻力组合；组合等权不代表真实先验分布，不能声称具有95%的实际事件覆盖。若网格尚未收敛或浅层连续介质近似不适用，首达、峰速和影响域均只作为算法情景探索。该模型无法直接表示高位冰体断裂、腾空飞行、融化、沟床侵蚀、堵江、漫溢及溃坝的全部链式过程。本文没有隐含声称已实现完整灾害链复现。')]
    extras[7]=[
        h('7.4 防灾策略与数据补齐优先级'),
        t('面向业务应用的分层监测与验证建议',['环节','优先补充内容','能解决的问题'],[
            ['源区','GNSS/雷达位移、裂隙、时变冰速、基底孔压','识别冰崩源区与失稳时刻，而非仅用气候态速度'],
            ['水源','源区雨雪与融水监测、实测时区和站点坐标','解释本站零雨与源区水源的不一致'],
            ['传播','沟道精细DEM、侵蚀率、现场流深/速度/到达记录','校准阻力与侵蚀，进行网格收敛和传播验证'],
            ['预警','独立事件与连续非事件档案、归档预报','建立事件级覆盖、漏报和误报评价'],
            ['暴露','居民点、道路口岸、建筑与逐对象人口','从县域人口转为可核实撤离对象'],
            ['外部补充','开放接口网络生效与第（3）数据分卷','执行新增卫星/天气与200千米冰川范围分析']]),
        p('空间评分用于部署踏勘与监测点，物理临界条件用于解释参数敏感性，代理气温区间用于说明不确定性校准方法，仿真用于检查给定初始与边界条件下的传播可能性。四者共同形成可审计研究流程，但不会自动合成为已经过业务验证的灾害预报系统。当前最重要的改进是补齐真实时间标签、源区观测与独立验证，而不是继续增加难以训练或难以解释的网络层数。')]
    abstract=[
        '针对吉隆县高寒山区“冰崩—碎屑流—泥石流—山洪”链式风险，本文建立由数据审计、近地层物理特征、条件稳定性、空间成员评分、分块区间预测与守恒型地形流动情景组成的可复现框架。研究把可由附件识别的量与依赖额外观测的量分开，避免用单事件、沟域编录或未标定仿真冒充经过验证的预报。',
        '问题一对四类各52,584个小时标签执行质量控制，在截至事件前的24小时窗口与155个季节—时刻匹配历史窗口之间比较稳健异常。前五项为40厘米土壤含水率、2米气温、24小时正积温、净辐射和72小时正积温，标准化差异依次为2.177、1.959、1.619、1.289和1.212。含水率首位的年簇重抽排名不稳定，气温与积温具有冗余。事件前本站24与72小时累计雨量均为零，不能将本站暴雨作为已证实触发原因。',
        '问题二将DEM重投影至米制坐标，以无限边坡和线性水库推导条件水力阈值，并用整沟域留出及2千米缓冲空间验证比较正则化逻辑回归与ExtraTrees。逻辑回归平均AUC约0.719，优于复杂树模型约0.699；结果仅为编录沟域成员评分。基准参数下30°浅层土坡的临界饱和比约0.427，属于未标定情景。外部遥感与气象接口被网络代理阻断，新增数值补充尚未完成。',
        f"问题三完成6小时超前气温代理的分位数回归与日块共形校准：2025独立年度测试MAE为{fc['temperature_MAE_C']:.3f}℃，365日中348日获得整日同时覆盖，覆盖率95.34%，平均区间宽12.14℃。这些成绩不属于泥石流触发时间预测。因附件没有独立灾害发生时间与连续非事件档案，真实事件的95%预测区间、预警提前量及覆盖率当前不可识别；本文给出相应风险率—生存函数算法和明确拒绝伪造标签的实现。",
        '问题四以真实DEM与冰川厚度构造11组释放—阻力情景，实施守恒数值计算、静止平衡与网格敏感性检查。独立数值审查用于识别和排除在零动量下依靠人工质量扩散传播的伪结果。最终结论受模型近似、参数未标定和地形尺度限制，所有传播距离与首达时间均保留情景含义。研究输出完整代码、中间数据、逐张600 dpi透明TIFF及EPS矢量图件，以及可编辑原生公式的Word和PDF。'
    ]
    output=[dict(type='abstract',text=x) for x in abstract]
    chapter=None
    for b in base:
        if b['type']=='h1':
            if chapter in extras:output+=extras.pop(chapter)
            m=re.match(r'(\d+)',b['text']);chapter=int(m.group(1)) if m else None
        output.append(b)
    if chapter in extras:output+=extras.pop(chapter)
    for _,bs in sorted(extras.items()):output+=bs
    output+=[dict(type='h1',text='参考文献')]
    refs=load('ext_bibliography.json')
    refs+=[dict(authors='Bates P D; Horritt M S; Fewtrell T J',year=2010,title='A simple inertial formulation of the shallow water equations for efficient two-dimensional flood inundation modelling',journal='Journal of Hydrology',volume='387',pages='33–45',doi='10.1016/j.jhydrol.2010.03.027'),dict(authors='de Almeida G A M; Bates P; Freer J E; Souvignet M',year=2012,title='Improving the stability of a simple formulation of the shallow water equations for 2-D flood modeling',journal='Water Resources Research',volume='48',pages='W05528',doi='10.1029/2011WR011570')]
    for i,d in enumerate(refs,1):
        st=f"[{i}] {d['authors']}. {d.get('year') or '无年份'}. {d['title']}. {d.get('journal','')}"
        if d.get('volume'):st+=', '+d['volume']
        if d.get('pages'):st+=': '+d['pages']
        if d.get('doi'):st+='. DOI: '+d['doi']
        elif d.get('url'):st+='. '+d['url']
        output.append(dict(type='ref',text=st+'。'))
    output+=[dict(type='ref',text='[13] 国家青藏高原科学数据中心. 赛题列示的八项吉隆灾害专题数据集及用户提供附件；原始来源链接详见赛题PDF，数值分析以实际可读附件为准。'),p('文献核验说明：共形预测作者官方仓库、Open-Meteo与Earth Search官方技术文档已成功读取；其余经典书目采用既有学术记录，Crossref联网核验受阻，未声称本次逐篇完成在线查验。完整核验状态、URL和失败响应见ext_bibliography.json、ext_summary.json。')]
    output+=[dict(type='appendix_section',text='附录　代码、数据与图件复现说明'),p('完整Python源代码单独交付，未用省略号删节；本附录列出执行关系，便于逐步核对论文。正文全部数学表达使用Word原生OMML对象，编号居中公式行右侧；内联公式也可直接编辑。OMML是Word原生数学格式，可由MathType支持的Word接口导入，但不是旧版MathType OLE嵌入对象。'),
        t('程序、对应题目与主要产物',['程序','作用','产物'],[
            ['met_analysis.py','问题一与问题三气温代理','met_*.csv/json'],['geo_analysis.py','问题二空间评估','geo_*.npz/csv/json'],['trigger_model.py','问题二解析临界条件','trigger_*.csv/json'],['simulation.py','问题四守恒流动情景','sim_*.npz/csv/json'],['external_data.py','公开资料下载与状态记录','ext_*.json与supplement文档'],['prospective_hazard.py','真实事件档案可得后的预报接口','当前明确不拟合'],['plot_results.py','统一样式与独立图件输出','每图TIFF/EPS/PNG'],['assemble_paper.py、build_paper.py','实测结果集成与原生公式排版','论文DOCX与PDF'],['run_all.py、validate_outputs.py','完整重跑与交付核查','日志与验证结果']]),
        p('复现时先阅读README_运行说明.md，按requirements.txt安装依赖，然后运行python code/run_all.py。外部接口默认读取本次失败记录而不假装已补齐数据；网络策略实际生效后使用external_data.py --retry。第（3）RAR需在合法可用的分卷或解压数据到位后另行扩展200千米范围分析。为了避免论文中的未知条件被静默忽略，所有未完成项同时保留在摘要、正文相应问题和交付说明中。'),
        p('字体按用户同意采用思源宋体；正文与标题字号分别遵照小四及指定层级。获取有授权的宋体后，设置CHINESE_FONT=SimSun及SIMSUN_FONT_FILE指向本地字体，并运行统一重绘与文档生成命令。图件TIFF为600 dpi透明RGBA；EPS不支持真正的alpha通道，本次EPS采用不绘制背景的矢量对象，不能声称EPS具备与TIFF同样的透明像素。浅色配色、字号与图例经过版面检查，但投稿是否达到特定期刊标准仍取决于研究证据、编辑规范和同行评议。')]
    # Renumber subsections after inserting empirical result sections. Source
    # methods and additions evolve independently; never leave gaps/duplicates.
    chapter=None;sub=0
    for block in output:
        if block['type']=='h1':
            match=re.match(r'(\d+)\s',block['text'])
            chapter=int(match.group(1)) if match else None;sub=0
        elif block['type']=='h2' and chapter is not None:
            sub+=1;block['text']=re.sub(r'^\d+\.\d+\s+',f'{chapter}.{sub} ',block['text'])
    M.mkdir(exist_ok=True)
    (M/'paper_blocks.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[];eq=fig=tab=0
    for b in output:
        typ=b['type']
        if typ.startswith('h') and len(typ)==2:lines+=['#'*int(typ[1])+' '+b['text'],'']
        elif typ=='eq':eq+=1;lines+=['$$',b['text']+r'\tag{'+str(eq)+'}','$$','']
        elif typ=='table':
            tab+=1;lines+=['表'+str(tab)+' '+b['title'],'|'+'|'.join(b['headers'])+'|','|'+'|'.join(['---']*len(b['headers']))+'|']
            lines+=['|'+'|'.join(map(str,row))+'|' for row in b['rows']];lines+=['']
        elif typ=='figure':fig+=1;lines+=['图'+str(fig)+' '+b.get('caption',''),b.get('interpretation',''),'文件：'+str(b.get('file','')),'']
        elif 'text' in b:lines+=[b['text'],'']
    (M/'完整建模方案与论文源稿.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Assembled',len(output),'blocks;',eq,'equations;',fig,'figures;',tab,'tables')

if __name__=='__main__':main()
