"""Build the Chinese competition paper with editable native Word equations.

All inline $...$ and displayed equations are converted to OMML, not pictures.
Use --toc-from <rendered.pdf> for a second pass with actual page numbers.
CHINESE_FONT switches text font; default Noto Serif CJK SC, SimSun when licensed.
"""
from pathlib import Path
import os, sys, re, json, argparse, subprocess, tempfile, zipfile, copy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.enum.section import WD_SECTION_START
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
from latex2mathml.converter import convert as latex2mml
from mathml2omml import convert as mml2omml

FONT=os.environ.get('CHINESE_FONT','Noto Serif CJK SC')
HEI=os.environ.get('HEADING_FONT','Noto Sans CJK SC')
OUT=ROOT/'manuscript'
MATH_NS='http://schemas.openxmlformats.org/officeDocument/2006/math'
MATH_CACHE={}

def elem(tag,**attrs):
    x=OxmlElement(tag)
    for k,v in attrs.items():x.set(qn(k),str(v))
    return x

def setfont(obj,name=FONT,size=12,bold=False):
    obj.font.name=name;obj.font.size=Pt(size);obj.font.bold=bold
    obj.font.color.rgb=RGBColor(0,0,0)
    rpr=obj._element.get_or_add_rPr()
    f=rpr.find(qn('w:rFonts'))
    if f is None:f=elem('w:rFonts');rpr.insert(0,f)
    for a in ['ascii','hAnsi','eastAsia','cs']:f.set(qn('w:'+a),name)

def math_node(s):
    if s in MATH_CACHE:return copy.deepcopy(MATH_CACHE[s])
    m=mml2omml(latex2mml(s))
    m=m.replace('<m:oMath>',f'<m:oMath xmlns:m="{MATH_NS}" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">',1)
    x=parse_xml(m)
    return x

def prepare_math(blocks):
    """Pandoc's mature TeX reader emits correct accents, cases and native OMML.

    The lightweight MathML converter has an XML accent-tag bug for bar/hat;
    a single batch conversion also preserves consistent Word equation semantics.
    """
    from lxml import etree
    formulas=[]
    def collect(x):
        if isinstance(x,dict):
            if x.get('type')=='eq':formulas.append(x['text'])
            for k,v in x.items():
                if k!='type' and not(k=='text' and x.get('type')=='eq'):collect(v)
        elif isinstance(x,list):
            for v in x:collect(v)
        elif isinstance(x,str):formulas.extend(re.findall(r'\$([^$]+)\$',x))
    collect(blocks);formulas=list(dict.fromkeys(formulas))
    with tempfile.TemporaryDirectory(prefix='mcm-math-') as td:
        out=Path(td)/'math.docx'
        src='\n\n'.join('$$\n'+f+'\n$$' for f in formulas)
        proc=subprocess.run(['pandoc','-f','markdown+tex_math_dollars','-t','docx','-o',str(out)],input=src,text=True,capture_output=True,check=True)
        if proc.stderr:(ROOT/'logs/pandoc_math.log').write_text(proc.stderr)
        with zipfile.ZipFile(out) as z:xml=etree.fromstring(z.read('word/document.xml'))
        nodes=xml.findall('.//{'+MATH_NS+'}oMath')
        if len(nodes)!=len(formulas):raise RuntimeError(f'OMML count mismatch {len(nodes)} vs{len(formulas)}')
        for f,node in zip(formulas,nodes):
            # Writer26's OMML importer mishandles scalable right square/ceiling
            # delimiters. Literal native math runs preserve their exact glyphs
            # in both Word and PDF while retaining editable equation structure.
            for delimiter in list(node.findall('.//{'+MATH_NS+'}d')):
                prop=delimiter.find('{'+MATH_NS+'}dPr')
                beg=prop.find('{'+MATH_NS+'}begChr') if prop is not None else None
                end=prop.find('{'+MATH_NS+'}endChr') if prop is not None else None
                bc=beg.get(qn('m:val'),'(') if beg is not None else '('
                ec=end.get(qn('m:val'),')') if end is not None else ')'
                if bc=='{' and ec=='':continue  # retain tall cases brace
                parent=delimiter.getparent();at=parent.index(delimiter)
                parts=[]
                def mr(txt):
                    r=elem('m:r');r.append(elem('m:rPr'));tt=elem('m:t');tt.text=txt;r.append(tt);return r
                if bc:parts.append(mr(bc))
                for inner in delimiter.findall('{'+MATH_NS+'}e'):parts.extend(list(inner))
                if ec:parts.append(mr(ec))
                parent.remove(delimiter)
                for offset,x in enumerate(parts):parent.insert(at+offset,x)
            for run in node.findall('.//{'+MATH_NS+'}r'):
                wp=elem('w:rPr');wp.append(elem('w:sz',**{'w:val':24}))
                wp.append(elem('w:rFonts',**{'w:ascii':'Latin Modern Math','w:hAnsi':'Latin Modern Math'}))
                run.insert(1 if run.find(qn('m:rPr')) is not None else 0,wp)
            MATH_CACHE[f]=node

def textmath(p,text,bold=False):
    for i,part in enumerate(re.split(r'\$([^$]+)\$',str(text))):
        if not part:continue
        if i%2:p._p.append(math_node(part))
        else:setfont(p.add_run(part),bold=bold)
    return p

def paragraph(doc,text='',style=None,bold=False):
    p=doc.add_paragraph(style=style)
    p.paragraph_format.line_spacing=1.35
    p.paragraph_format.space_after=Pt(6)
    if style is None:p.paragraph_format.first_line_indent=Pt(24)
    textmath(p,text,bold)
    return p

def bookmark(p,name):
    global bookmark_id
    bookmark_id+=1
    st=elem('w:bookmarkStart',**{'w:id':bookmark_id,'w:name':name})
    en=elem('w:bookmarkEnd',**{'w:id':bookmark_id})
    p._p.insert(0,st);p._p.append(en)

def heading(doc,text,level):
    p=doc.add_heading(text,level=level)
    p.paragraph_format.first_line_indent=Pt(0)
    p.paragraph_format.keep_with_next=True
    for r in p.runs:setfont(r,HEI if level==1 else FONT,15 if level==1 else 14 if level==2 else 12,True)
    bookmark(p,'s'+str(len(heading_records)))
    heading_records.append((level,text))
    return p

def equation(doc,text):
    global eqcount
    eqcount+=1
    p=doc.add_paragraph()
    p.paragraph_format.tab_stops.add_tab_stop(Cm(8.1),WD_TAB_ALIGNMENT.CENTER)
    p.paragraph_format.tab_stops.add_tab_stop(Cm(16.2),WD_TAB_ALIGNMENT.RIGHT)
    p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(7)
    p.paragraph_format.keep_together=True
    p.add_run('\t');p._p.append(math_node(text));setfont(p.add_run('\t（'+str(eqcount)+'）'))
    return p

def caption(doc,text):
    p=doc.add_paragraph(style='Heading 5')
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent=Pt(0)
    p.paragraph_format.keep_with_next=False
    p.paragraph_format.space_before=Pt(4)
    textmath(p,text,True)
    return p

def table(doc,headers,rows,title):
    global tabcount
    tabcount+=1
    p=caption(doc,f'表{tabcount}　{title}')
    p.paragraph_format.keep_with_next=True
    t=doc.add_table(rows=1,cols=len(headers))
    t.autofit=True
    t.alignment=WD_ALIGN_PARAGRAPH.CENTER
    pr=t._tbl.tblPr
    borders=elem('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        borders.append(elem('w:'+side,**{'w:val':'nil'}))
    pr.append(borders)
    for i,h in enumerate(headers):textmath(t.rows[0].cells[i].paragraphs[0],h,True)
    rep=elem('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(rep)
    for vals in rows:
        cells=t.add_row().cells
        for c,v in zip(cells,vals):textmath(c.paragraphs[0],str(v))
    for ri,row in enumerate(t.rows):
        row._tr.get_or_add_trPr().append(elem('w:cantSplit'))
        for c in row.cells:
            c.vertical_alignment=1
            tcpr=c._tc.get_or_add_tcPr();bd=elem('w:tcBorders')
            if ri==0:
                for side in ['top','bottom']:bd.append(elem('w:'+side,**{'w:val':'single','w:sz':27,'w:color':'000000'}))
            if ri==len(t.rows)-1:bd.append(elem('w:bottom',**{'w:val':'single','w:sz':27,'w:color':'000000'}))
            tcpr.append(bd)
            for p in c.paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.first_line_indent=Pt(0)
                p.paragraph_format.line_spacing=1.15
                p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3)
                p.paragraph_format.keep_with_next=(ri<len(t.rows)-1)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t

def figure(doc,item):
    global figcount
    figcount+=1
    # Embed lossless full-resolution PNG converted from600dpi TIFF, if available.
    path=Path(item.get('png',item.get('file','')))
    if not path.is_absolute():path=ROOT/path
    if path.suffix.lower() in ['.tiff','.tif']:
        from PIL import Image
        png=path.with_name(path.stem+'_paper.png')
        Image.open(path).save(png,dpi=(600,600));path=png
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(path),width=Cm(16.2))
    caption(doc,f'图{figcount}　'+item.get('caption',path.stem))
    fn=item.get('tiff',item.get('file',path.name))
    note=paragraph(doc,'图件文件：'+Path(fn).name+'；同名 EPS 为矢量版本。')
    note.paragraph_format.first_line_indent=Pt(0)
    if item.get('interpretation'):paragraph(doc,item['interpretation'])

def field(p,code):
    r=p.add_run();r._r.append(elem('w:fldChar',**{'w:fldCharType':'begin'}))
    it=elem('w:instrText');it.set(qn('xml:space'),'preserve');it.text=' '+code+' ';r._r.append(it)
    r._r.append(elem('w:fldChar',**{'w:fldCharType':'separate'}))
    t=elem('w:t');t.text='1';r._r.append(t)
    r._r.append(elem('w:fldChar',**{'w:fldCharType':'end'}))

def setup(doc):
    for s in doc.sections:
        s.page_width=Cm(21);s.page_height=Cm(29.7)
        s.top_margin=Cm(2.1);s.bottom_margin=Cm(2.0)
        s.left_margin=Cm(2.4);s.right_margin=Cm(2.4)
        s.header_distance=Cm(.8);s.footer_distance=Cm(.9)
    for st in ['Normal','Body Text','Heading 1','Heading 2','Heading 3','Heading 5']:
        style=doc.styles[st]
        style.font.name=FONT;style.font.size=Pt(12)
        rf=style.element.get_or_add_rPr()
        fs=elem('w:rFonts',**{'w:eastAsia':FONT,'w:ascii':FONT,'w:hAnsi':FONT});rf.insert(0,fs)
        style.font.color.rgb=RGBColor(0,0,0)
    doc.styles['Heading 1'].font.name=HEI
    for st,sz in [('Heading 1',15),('Heading 2',14),('Heading 3',12),('Heading 5',12)]:
        doc.styles[st].font.size=Pt(sz);doc.styles[st].font.bold=True
    doc.core_properties.title='高寒灾害链的物理约束建模与不确定性评估'
    doc.core_properties.subject='MathorCup赛道B四问：真实附件分析、物理阈值、代理预测与守恒仿真'
    doc.core_properties.author=''
    doc.settings.element.append(elem('w:updateFields',**{'w:val':'true'}))
    mp=doc.settings.element.find(qn('m:mathPr'))
    if mp is None:mp=elem('m:mathPr');doc.settings.element.append(mp)
    mf=mp.find(qn('m:mathFont'))
    if mf is None:mf=elem('m:mathFont');mp.insert(0,mf)
    mf.set(qn('m:val'),'Latin Modern Math')

def toc(doc,headings,pages):
    p=doc.add_paragraph();p.alignment=1;setfont(p.add_run('目　录'),HEI,16,True)
    p.paragraph_format.page_break_before=True
    for i,(lvl,text) in enumerate(headings):
        if lvl>2:continue
        p=doc.add_paragraph();p.paragraph_format.line_spacing=1.1
        p.paragraph_format.space_after=Pt(4)
        p.paragraph_format.left_indent=Cm(.55 if lvl==2 else 0)
        p.paragraph_format.tab_stops.add_tab_stop(Cm(16.2-(.55 if lvl==2 else 0)),WD_TAB_ALIGNMENT.RIGHT,WD_TAB_LEADER.DOTS)
        link=elem('w:hyperlink',**{'w:anchor':'s'+str(i),'w:history':'1'})
        run=elem('w:r');rp=elem('w:rPr');rp.append(elem('w:rFonts',**{'w:eastAsia':FONT,'w:ascii':FONT,'w:hAnsi':FONT}))
        rp.append(elem('w:sz',**{'w:val':24}));run.append(rp)
        tx=elem('w:t');tx.text=text;run.append(tx);link.append(run);p._p.append(link)
        setfont(p.add_run('\t'+str(pages.get(text,'—'))),bold=(lvl==1))

def read_pages(path,headings):
    if not path:return {}
    import fitz
    pdf=fitz.open(path);pages={}
    clean=lambda s:re.sub(r'\s+','',s)
    start=None
    target=clean(headings[0][1])
    # Ignore TOC matches: body contains first heading and its explanatory prose.
    for i,p in enumerate(pdf):
        txt=clean(p.get_text())
        if target in txt and '问题重述' in txt and txt.count('数据审计')<1:
            start=i;break
    if start is None:
        matches=[i for i,p in enumerate(pdf) if target in clean(p.get_text())]
        start=matches[-1] if matches else 0
    for _,h in headings:
        for i in range(start,len(pdf)):
            if clean(h) in clean(pdf[i].get_text()):pages[h]=i-start+1;break
    return pages

def build(args):
    global eqcount,figcount,tabcount,bookmark_id,heading_records
    eqcount=figcount=tabcount=bookmark_id=0;heading_records=[]
    blocks=json.loads((OUT/'paper_blocks.json').read_text())
    prepare_math(blocks)
    headings=[(int(b['type'][1]),b['text']) for b in blocks if re.fullmatch('h[123]',b['type'])]
    pages=read_pages(args.toc_from,headings)
    doc=Document();setup(doc)
    p=doc.add_paragraph();p.alignment=1
    p.paragraph_format.space_before=Pt(60)
    setfont(p.add_run('高寒灾害链的物理约束建模\n与不确定性评估'),HEI,16,True)
    p=doc.add_paragraph();p.alignment=1;setfont(p.add_run('——以吉隆县冰崩—泥石流链式风险为例'),HEI,16,True)
    p=doc.add_paragraph();p.alignment=1;p.paragraph_format.space_before=Pt(24)
    setfont(p.add_run('2026 年 MathorCup 数学应用挑战赛\n大数据竞赛赛道 B · 初赛论文'))
    p=doc.add_paragraph();p.alignment=1;p.paragraph_format.space_before=Pt(36)
    setfont(p.add_run('附件实证分析 · 可复现算法 · 情景仿真'))
    paragraph(doc,'说明：本文依据用户提供的赛题与可读取附件形成。事件叙述采用赛题设定，未将其视为独立核实的新闻事实。所有数值区分观测计算、代理任务验证与未标定参数情景；不以情景结果代替真实灾害预报。')
    p=doc.add_paragraph();p.alignment=1;setfont(p.add_run('摘　要'),HEI,16,True)
    p.paragraph_format.page_break_before=True
    for b in blocks:
        if b['type']=='abstract':
            ap=paragraph(doc,b['text']);ap.paragraph_format.line_spacing=1.15
            ap.paragraph_format.space_after=Pt(4)
    p=paragraph(doc,'关键词：高寒灾害链；边界层过程；正例—未标记学习；分块共形预测；守恒型有限体积；可识别性',bold=True)
    toc(doc,headings,pages)
    sec=doc.add_section(WD_SECTION_START.NEW_PAGE)
    sec.footer.is_linked_to_previous=False
    pg=elem('w:pgNumType',**{'w:start':1});sec._sectPr.append(pg)
    p=sec.footer.paragraphs[0];p.alignment=1;field(p,'PAGE')
    for r in p.runs:setfont(r,size=10.5)
    for b in blocks:
        typ=b['type']
        if typ=='abstract':continue
        if re.fullmatch('h[123]',typ):heading(doc,b['text'],int(typ[1]))
        elif typ=='p':paragraph(doc,b['text'])
        elif typ=='eq':equation(doc,b['text'])
        elif typ=='table':table(doc,b['headers'],b['rows'],b['title'])
        elif typ=='figure':figure(doc,b)
        elif typ=='pagebreak':doc.add_page_break()
        elif typ=='ref':
            p=paragraph(doc,b['text']);p.paragraph_format.first_line_indent=Pt(0)
            p.paragraph_format.left_indent=Pt(24);p.paragraph_format.first_line_indent=Pt(-24)
        elif typ=='appendix_section':
            sec=doc.add_section(WD_SECTION_START.NEW_PAGE)
            sec.footer.is_linked_to_previous=False
            for p in sec.footer.paragraphs:p.clear()
            heading(doc,b['text'],1)
    out=OUT/'吉隆灾害链建模论文.docx';doc.save(out)
    (OUT/'render_metadata.json').write_text(json.dumps(dict(equations=eqcount,figures=figcount,tables=tabcount,font=FONT,headings=heading_records,toc_pages=pages),ensure_ascii=False,indent=2))
    print(out);print(f'{eqcount} native equations; {figcount} figures; {tabcount} three-line tables')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--toc-from');build(ap.parse_args())
