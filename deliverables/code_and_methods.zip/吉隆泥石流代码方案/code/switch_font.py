"""One-command licensed SimSun switch and full figure/document rerender.

python code/switch_font.py --font /path/to/simsun.ttc
The font file is never downloaded from an unlicensed mirror.
"""
from pathlib import Path
import argparse,os,subprocess,sys

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--font',required=True,help='Local licensed SimSun TTF/TTC file')
    ap.add_argument('--word-name',default='SimSun',help='Installed family name recognized by Word/LibreOffice')
    a=ap.parse_args();font=Path(a.font).expanduser().resolve()
    if not font.is_file():raise FileNotFoundError(font)
    env=os.environ.copy();env['CHINESE_FONT']=a.word_name;env['SIMSUN_FONT_FILE']=str(font)
    print('Figures use the provided font; install the same family for Word/PDF before rerendering.')
    root=Path(__file__).resolve().parents[1]
    subprocess.run([sys.executable,str(root/'code/run_all.py'),'--start-from','plot_results'],env=env,check=True)

if __name__=='__main__':main()
