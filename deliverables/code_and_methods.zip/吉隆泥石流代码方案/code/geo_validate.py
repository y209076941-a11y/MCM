"""Independent consistency checks for the derived geospatial outputs."""
from pathlib import Path
import json,numpy as np,pandas as pd
R=Path(__file__).resolve().parents[1]/'results';a=np.load(R/'geo_grid.npz');s=json.loads((R/'geo_summary.json').read_text())
m=a['mask'];acc=a['flowacc'];down=a['downstream'];outlet=m&(down<0)
checks={}
checks['D8_outlet_contributing_cells']=float(acc[outlet].sum());checks['valid_cells']=int(m.sum())
assert abs(checks['D8_outlet_contributing_cells']-checks['valid_cells'])<1e-8
th=np.radians(a['slope']);sat=a['critical_saturation'];rho=1800.;g=9.81;h=1.5;c=2000.;phi=np.radians(32.)
fs=(c+(rho-1000*sat)*g*h*np.cos(th)**2*np.tan(phi))/(rho*g*h*np.sin(th)*np.cos(th))
checks['critical_saturation_FS_max_abs_error']=float(np.nanmax(np.abs(fs[m]-1)))
assert checks['critical_saturation_FS_max_abs_error']<.02
assert np.nanmin(a['slope'])>=0 and np.nanmax(a['slope'])<90
score=a['score'];assert np.nanmin(score)>=0 and np.nanmax(score)<=1
checks['population_sex_total']=s['population']['male']+s['population']['female'];assert checks['population_sex_total']==s['population']['total_population_field']
checks['population_urban_rural_total']=s['population']['urban']+s['population']['rural'];assert checks['population_urban_rural_total']==s['population']['total_population_field']
tr=pd.read_csv(R/'geo_landcover_transition.csv');areas=pd.read_csv(R/'geo_landcover_area.csv')
checks['landcover_transition_km2']=float(tr.area_km2.sum());checks['landcover_2023_km2']=float(areas.query('year==2023').area_km2.sum());checks['landcover_2020_km2']=float(areas.query('year==2020').area_km2.sum()); assert checks['landcover_transition_km2']<=min(checks['landcover_2020_km2'],checks['landcover_2023_km2']); checks['landcover_2023_outside_common_valid_km2']=checks['landcover_2023_km2']-checks['landcover_transition_km2']; checks['landcover_2020_outside_common_valid_km2']=checks['landcover_2020_km2']-checks['landcover_transition_km2']
checks['passed']=True
(R/'geo_validation.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
