"""Q2 supplementary-data acquisition (public endpoints; TLS always verified).

No raw external weather/satellite data was acquired during the original run:
all three API domains were denied by the managed HTTPS proxy (CONNECT 403).
Run only after network settings have actually been applied, or with --retry.
Returned reanalysis MUST NOT be labeled an issued forecast. Acquisition writes
provenance and an explicit status for every request; failures never become zeros.
"""
from __future__ import annotations
import argparse, csv, datetime as dt, hashlib, json, sys
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / 'supplement'
RESULTS = ROOT / 'results'
LAT, LON = 28.4, 85.44
BBOX = [85.40,28.36,85.48,28.44]

def fetch_json(name: str, url: str) -> tuple[dict, dict | None]:
    rec = {'name':name,'url':url,'request_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
           'tls_verified':True,'status':'failed'}
    try:
        with urlopen(Request(url,headers={'User-Agent':'MCM-reproducible-research/1.0'}),timeout=30) as r:
            raw=r.read()
            obj=json.loads(raw)
            if isinstance(obj,dict) and obj.get('error'):
                raise RuntimeError(str(obj.get('reason',obj)))
            path=OUT / (name+'.json');path.write_bytes(raw)
            rec.update(status='downloaded',http_status=r.status,bytes=len(raw),
                       sha256=hashlib.sha256(raw).hexdigest(),file=str(path.relative_to(ROOT)))
            return rec,obj
    except Exception as e:
        rec.update(error_type=type(e).__name__,error=str(e))
        return rec,None

def export_weather(name: str, obj: dict, role: str) -> dict:
    hourly=obj.get('hourly',{})
    times=hourly.get('time',[])
    if not times:raise ValueError('No actual hourly data returned')
    fields=list(hourly)
    path=OUT/(name+'.csv')
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(fields)
        w.writerows(zip(*(hourly[c] for c in fields)))
    return {'role':role,'n_hours':len(times),'first_time':times[0],'last_time':times[-1],
            'hourly_units':obj.get('hourly_units'),'returned_latitude':obj.get('latitude'),
            'returned_longitude':obj.get('longitude'),'returned_elevation':obj.get('elevation'),
            'utc_offset_seconds':obj.get('utc_offset_seconds'),
            'warning':'API interpolation/downscaling is not a local station observation. Reanalysis lacks a historical issuance time.'}

def export_stac(obj:dict)->dict:
    features=obj.get('features',[])
    records=[]
    for f in features:
        p=f.get('properties',{});a=f.get('assets',{})
        records.append({'id':f.get('id'),'datetime':p.get('datetime'),
                        'cloud_cover_pct':p.get('eo:cloud_cover'),'bbox':f.get('bbox'),
                        'red_asset':a.get('red'),'nir_asset':a.get('nir'),
                        'scl_asset':a.get('scl')})
    (OUT/'sentinel2_selected_assets.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
    return {'n_items':len(features),'items':records,
            'warning':'STAC metadata is not pixel reflectance or NDVI. No NDVI exists until assets are read, gain/offset applied and cloud/nodata masking performed.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--retry',action='store_true',help='Run requests after network settings actually changed')
    args=ap.parse_args()
    if not args.retry:
        print('Not retried: original APIs were CONNECT-403 blocked. Apply network settings, then invoke --retry.')
        return
    OUT.mkdir(parents=True,exist_ok=True)
    common={'latitude':LAT,'longitude':LON,'hourly':'temperature_2m,precipitation,relative_humidity_2m','timezone':'UTC'}
    queries=[
      ('era5_2025_summer','https://archive-api.open-meteo.com/v1/archive?'+urlencode(common|{'start_date':'2025-06-01','end_date':'2025-08-31','models':'era5'}),'reanalysis_background_only'),
      ('sentinel2_pre_event','https://earth-search.aws.element84.com/v1/search?'+urlencode({'collections':'sentinel-2-l2a','bbox':','.join(map(str,BBOX)),'datetime':'2026-06-01T00:00:00Z/2026-08-25T23:59:59Z','limit':20}),'satellite_metadata_only'),
    ]
    summary=[]
    for name,url,role in queries:
        record,obj=fetch_json(name,url)
        if obj is not None:
            try:record['details']=export_stac(obj) if name.startswith('sentinel') else export_weather(name,obj,role)
            except Exception as e:record.update(status='validation_failed',error=str(e))
        summary.append(record)
    (RESULTS/'ext_retry.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
