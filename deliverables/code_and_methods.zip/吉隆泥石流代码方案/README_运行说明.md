# 吉隆灾害链建模：代码、数据、图件与论文复现

本目录是独立研究工程，不依赖先前静态 HTML 仓库。所有统计值均来自可读取的附件、明确标记的代理预测任务或假设参数情景。请先阅读论文中的数据审计、模型适用条件和局限性。

## 文件与问题对应关系

| 位置 | 内容 |
| --- | --- |
| `data/dataset_1` | MET、RADM、SOIL、FLUX 小时 CSV；52,584 小时时间网格不等于每个时刻均有有效观测 |
| `data/dataset_2` | 2005—2025 年五县逐日气温，2025 年不完整 |
| `data/dataset_4` | 冰川地形、厚度、速度 NetCDF |
| `data/dataset_5` | 2020—2023 年土地覆盖 TIFF |
| `data/dataset_6` | 历史灾害清单矢量及属性；不能直接当作独立的精确触发时间样本 |
| `data/dataset_7` | DEM 及原始附属信息；获取日期不足以确证灾前地形 |
| `data/dataset_8` | 人口普查矢量及属性；无可支持逐建筑人口的栅格分配 |
| `code/met_analysis.py` | 问题一：质控、物理量、匹配对照、异常排序、重抽样、气温趋势；问题三：气温代理的时序分块共形验证 |
| `code/geo_analysis.py` | 问题二：GIS 对齐、地形、水文、冰川指标、空间正例—未标记清单隶属评估与缓冲分块验证 |
| `code/trigger_model.py` | 问题二：无限边坡—线性水库的解析阈值与材料参数敏感性 |
| `code/simulation.py` | 问题四：守恒浅层数值情景、数值基准验证、参数与网格敏感性 |
| `code/external_data.py` | 补充数据获取与来源记录；默认不重试网络 |
| `code/plot_results.py` | 浅色统一配色，中文标注，逐张 TIFF、EPS、PNG 输出 |
| `code/assemble_paper.py` | 读取计算结果和写作素材，构造论文内容块 |
| `code/build_paper.py` | 原生可编辑 OMML 公式、三线表、图件、目录、正文页码及 DOCX |
| `code/run_all.py` | 完整顺序运行与双遍 PDF/目录生成 |
| `code/validate_outputs.py` | 数值守恒、阈值一致性、代理覆盖率、图件元数据和 Word 结构校验 |
| `results/` | 所有指标 CSV、汇总 JSON、栅格中间结果、图件清单与校验报告 |
| `figures/` | 每图独立保存；TIFF 为透明 RGBA、600 dpi，EPS 为矢量格式 |
| `manuscript/` | 论文 Word/PDF、内容块与渲染元数据；具体以目录实际文件为准 |
| `logs/` | 每步完整标准输出和错误日志 |

## 推荐环境与安装

验证环境为 Linux、Python 3.12。直接依赖的固定版本见 `requirements.txt`，不把整台机器的无关依赖冻结到工程中。GIS 的 GDAL、PROJ、HDF5 等由相应 Python wheel 提供；若平台不能使用 wheel，应根据本机软件源安装受支持的系统库。

```bash
cd /path/to/MCM_study
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

云端已有依赖位于工程的 `vendor/` 时，启动器会统一设置 `PYTHONPATH` 使用它；交付压缩包不包含数百 MB 的 `vendor/`，请在本机创建上述虚拟环境。数值环境、字体或系统渲染版本变化可能产生末位数值、分页或字形度量差异，应以计算结果与校验报告为准。

PDF 导出还需要 LibreOffice（提供 `soffice` 或 `libreoffice` 命令）。它是系统软件，不是 pip 包。在受管理环境中请通过允许的软件安装流程安装，不要关闭 TLS 或软件包签名校验。

## 一键执行与恢复执行

```bash
python code/run_all.py
```

顺序为：气象分析 → GIS 分析 → 触发阈值 → 数值仿真 → 外部获取状态检查 → 绘图 → 论文组装 → Word → PDF 第一遍 → 回填真实目录页码 → PDF 第二遍 → 总体验证。失败时立即保留底层返回码并停止，详细信息写入 `logs/`。默认不会发起外部数据重试。

可按需恢复：

```bash
# 已有数据结果，只重画图并重建论文
python code/run_all.py --start-from plot_results
# 只运行数值、图件；缺少论文不会被伪报成已完成
python code/run_all.py --skip-paper
# 暂无 LibreOffice，先生成 Word
python code/run_all.py --skip-pdf
# 只校验已交付成品
python code/validate_outputs.py
# 正文仍在编排时，仅允许论文尚未生成
python code/validate_outputs.py --allow-incomplete-paper
```

逐项运行也可；工作目录建议设为工程根目录。不要同时运行两套流水线覆盖同一组结果。原始附件不由代码修改，数值与成品均写入 `results/`、`figures/`、`manuscript/`、`logs/`。

## 字体、透明度和图片规格

用户已同意使用**思源宋体**作为当前可分发的宋体风格替代。工程自带 `data/NotoSerifCJKsc-Regular.ttf`、加粗字体及其随附许可文件（若已由打包步骤放入），所有中文图件使用同一字体；不将它冒称为 Windows 宋体。

若本机有合法宋体字体，先在系统安装相应字体，再设置：

```bash
export CHINESE_FONT=SimSun
export SIMSUN_FONT_FILE=/absolute/path/to/simsun.ttf
python code/run_all.py --start-from plot_results
```

`CHINESE_FONT` 用于 Word 正文，`SIMSUN_FONT_FILE` 指定绘图字体文件；标题黑体使用系统支持的黑体风格字体。两者需要都可被实际渲染程序读取，否则仅声明字体名不能保证正确字形。

TIFF 文件使用 600 dpi、LZW、RGBA 透明背景，源图字体不小于 14 磅。Word 以接近原始尺寸插图，保持字体可读。EPS 标准**不支持 alpha 透明通道**，因此 EPS 只能省略背景矩形，不能等同于 RGBA TIFF 的逐像素透明。为避免中文依赖接收方字体，EPS 可使用嵌入字形路径/Type 3 字体；它是矢量字形，但不保证所有出版商均接受 Type 3，投稿时还应检查具体期刊规范。图件风格参考高水平期刊的清晰、节制原则，不构成出版级别或录用保证。

## 必须保留的解释边界

1. 题目事件叙述按赛题设定使用，未把题目文字当成独立核实的新闻事实。小时数据需逐变量剔除缺测码和非零质量标志，不能把未观测降雨补为零。
2. 问题一的“五因素”是单事件、季节和时刻匹配的描述性异常排序，不是有足够独立灾害样本支持的因果结论。含水率排名不稳定，温度与正积温存在冗余；相关矩阵、重抽排名和窗口敏感性结果均提供。
3. 气温长期趋势按完整年份分析；2025 年缺失末段，不能直接与全年平均比较。1—20 米观测刻画近地表层，不能推断完整大气边界层高度。
4. 空间模型分数表示样本设计下历史清单隶属程度；未标记地区可能含漏报灾害，分数不能直接当作已校准的发生概率。
5. 边坡临界降雨、黏聚力、摩擦角、孔压和水库参数为未标定情景。土壤体积含水率不等于孔压或饱和厚度比；无限边坡土层模型不等于冰川破裂模型。
6. 问题三实际验证的是**六小时超前测站气温**的代理任务，测试覆盖率不能替代泥石流触发时间区间覆盖率。附件缺少足够独立、准确标时的灾害事件，以及历史签发天气预报，因此未识别真实泥石流的 95% 时间区间和真实预警提前量。
7. 情景集合的分位数不是已校准预测区间。仿真源区由算法选取，释放量、摩阻等为情景；真实冰崩、挟沙、融化、堵江溃决、建筑阻挡等过程未全部模拟。须结合数值基准和网格敏感性阅读结果，不作工程避险半径或真实口岸到达时间保证。

## 外部数据和未能读取的附件

补充天气、遥感和相关 API 的实际尝试被管理代理拒绝（CONNECT HTTP 403）；`results/ext_summary.json` 记录证据和引用信息。**没有成功取得的外部卫星像元、预报或再分析数值均未进入实证结果**。再分析即使下载成功，也不能冒称历史签发预报；STAC 元数据不是影像像元或 NDVI。

网络设置确实改变后，可显式执行：

```bash
python code/external_data.py --retry
```

这只获取并校验数据、记录来源，不会自动把新增来源融入已经完成的模型或论文。应进一步核查时空匹配、观测/预报角色和版本，再设计新的无泄漏实验。

附件（3）的 RAR 大于当前单文件 32 MiB 传输限额，未能下载，因此工程不包含其解压数据或基于它计算的结论。若后续获得可读取的原始文件或每份小于 32 MiB 的正规分卷，应补充冰川长期变化分析并重新验证，而不能用虚构数据填补。

## Word 与 PDF 排版

公式由 LaTeX 源转换为 **Word 原生 OMML**，正文与行内公式不保留美元定界符或代码式下标；OMML 可在 Word 直接显示和编辑，不依赖图片。原生 OMML 与第三方 MathType OLE 对象不是同一种文件结构，不能将 OMML 冒称为 MathType 插件对象。

正文、标题、图表标题和页脚由 `build_paper.py` 统一设置。数据表以三线表方式设置黑色 2.25 磅边线，单元格内容居中；公式居中且编号置右；正文从目录之后开始编号，附录按文稿结构处理。PDF 通过 LibreOffice 双遍导出并回填目录页码。实际成品还需逐页人工检查跨页表、孤行、图注与阅读顺序；自动校验不能保证任何字体环境下的分页完全一致。

## 数值与成品校验

`validate_outputs.py` 检查代理预测覆盖率与原始逐时对是否一致、预测时距是否六小时、水文汇流守恒、解析临界饱和度处安全系数残差、仿真质量守恒及数值基准证据、TIFF 的 600 dpi/透明通道、EPS 文件头、Word 原生公式和三线表属性。结果写入 `results/validation_report.json`。校验通过只证明这些具体约束成立，不证明真实灾害预报已得到验证。

数据和参考文献的来源、元数据与未能在线核实的文献记录均应保留。使用或公开附件前，请按原始数据提供方的使用条款正确引用。

## 补充系统依赖与一键字体切换

原生公式的批量转换使用 Pandoc；PDF 导出使用 LibreOffice（soffice）。这两个是系统程序，不属于 pip requirements。运行前请确认 `pandoc --version` 和 `soffice --version` 可执行。Linux 可通过系统包管理器安装 pandoc、libreoffice-writer 及中文字体。

授权宋体已安装后可运行 `python code/switch_font.py --font /本地路径/simsun.ttc`，自动重绘并重新生成 Word/PDF。当前用户选择的思源宋体是成品默认字体。所有关键参数汇总在 `results/parameter_index.json`，具体控制参数以对应源程序为准。

论文的完整方案源稿为 `manuscript/完整建模方案与论文源稿.md`；Word 中所有显示及行内公式已转换为原生 OMML，不是截图。最终仿真为保留完整动量平流的摩擦平衡预测—校正算法；曾被审查否决的中间格式仅保留在审查日志中，未用于最终图表。
